'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import { Monitor, Usb, Power, RotateCcw, ArrowLeft, HelpCircle, ListChecks, CheckCircle2, Circle, Wifi, BookOpen, Maximize2, ChevronDown } from 'lucide-react';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { HARDWARE, OS_NAMES, TASKS, SOURCES, type OS } from '@/lib/sim/config';
import { initial, power, boot, enterInstaller, finishJob, setScenario, type Machine } from '@/lib/sim/machine';
import { validate } from '@/lib/sim/disk';
import { removeMediaAndReboot } from '@/lib/sim/flows';
import { hints } from '@/lib/sim/hints';
import { Hardware } from './Hardware';
import { Media } from './Media';
import { WindowsInstaller, WindowsOobe } from './Windows';
import { UbuntuInstaller, UbuntuLogin, UbuntuWelcome } from './Ubuntu';
import { Desktop } from './Desktop';
import { type Edit, type Confirm, Pick, Processing, WinMark } from './ui';
import {Localization} from './Localization';
import {audit} from '@/lib/sim/audit';
import {UsbBench, Practice, CommandManual} from './Practice';
export default function Simulator({fixedOS}:{fixedOS?:OS}={}) {
    const KEY = 'instalalab-practica-v2-'+(fixedOS||'both');
    const [sessions, setSessions] = useState<Partial<Record<OS, Machine>>>(()=>fixedOS?{[fixedOS]:initial(fixedOS)}:{});
    const [active, setActive] = useState<OS | null>(fixedOS||null);
    const [loaded, setLoaded] = useState(false);
    const [saveError, setSaveError] = useState('');
    const [now, setNow] = useState(Date.now());
    const [confirmData, setConfirmData] = useState<{
        title: string;
        text: string;
        action: () => void;
    } | null>(null);
    const [help, setHelp] = useState(false);
    const [hint, setHint] = useState(0);
    const [info, setInfo] = useState(false);
    const [tasks, setTasks] = useState(true);
    const stateRef = useRef<Machine | null>(null);
    const s = active ? sessions[active] || null : null;
    stateRef.current = s;
    useEffect(() => { try {
        const raw = localStorage.getItem(KEY);
        if (raw) {
            const data = JSON.parse(raw);
            for (const v of Object.values(data.sessions || {}) as Machine[]) {
                if (v.version !== 1)
                    throw Error('Versión no compatible');
                validate(v.disk);
                if(v.os==='ubuntu'&&v.settings.method==='automated'){v.settings.method='interactive';if(!v.tasks[2]){v.screen='installer';v.step=5;v.user.password='';v.user.confirm='';}}
            }
            setSessions(data.sessions || {});
            setActive(fixedOS || data.active || null);
        }
    }
    catch {
        setSaveError('No se pudo recuperar la sesión guardada. Puedes iniciar una nueva.');
    } if(fixedOS){setActive(fixedOS);setSessions(prev=>({...prev,[fixedOS]:prev[fixedOS]||initial(fixedOS)}));} setLoaded(true); }, [fixedOS,KEY]);
    useEffect(() => { if (!loaded)
        return; try {
        localStorage.setItem(KEY, JSON.stringify({ sessions, active }));
    }
    catch {
        setSaveError('El navegador no permite guardar el progreso. Mantén esta pestaña abierta.');
    } }, [sessions, active, loaded]);
    const edit: Edit = useCallback(fn => { if (!active)
        return; setSessions(prev => { const source = prev[active]; if (!source)
        return prev; const n = structuredClone(source); try {
        n.error = '';
        fn(n);
        validate(n.disk);
        audit(source,n);
        return { ...prev, [active]: n };
    }
    catch (e) {
        return { ...prev, [active]: { ...source, error: (e as Error).message, history:[...source.history,new Date().toLocaleTimeString('es-ES')+' · Incidencia: '+(e as Error).message] } };
    } }); }, [active]);
    const confirm: Confirm = (title, text, action) => setConfirmData({ title, text, action });
    useEffect(() => { const id = setInterval(() => setNow(Date.now()), 200); return () => clearInterval(id); }, []);
    useEffect(() => { if (s?.job && now >= s.job.start + s.job.duration)
        edit(finishJob); }, [now, s?.job, edit]);
    useEffect(() => { setHint(0); setHelp(false); }, [s?.screen, s?.step]);
    useEffect(() => { if (s?.screen !== 'usbPrompt')
        return; const id = setTimeout(() => edit(n => boot(n, 'ssd')), 6500); return () => clearTimeout(id); }, [s?.screen, edit]);
    const key = useCallback((code: string) => { const current = stateRef.current; if (!current)
        return; if (current.screen === 'post' && (code === 'F2' || code === 'F12'))
        edit(n => { n.job = null; n.screen = code === 'F2' ? 'uefi' : 'bootMenu'; });
    else if (current.screen === 'usbPrompt')
        edit(enterInstaller);
    else if (current.screen === 'removeMedia' && code === 'Enter')
        edit(removeMediaAndReboot); }, [edit]);
    useEffect(() => { const fn = (e: KeyboardEvent) => { if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName))
        return; if (['F2', 'F12', 'Enter'].includes(e.key) || stateRef.current?.screen === 'usbPrompt') {
        e.preventDefault();
        key(e.key);
    } }; window.addEventListener('keydown', fn); return () => window.removeEventListener('keydown', fn); }, [key]);
    useEffect(() => { const context = (document as Document & {
        modelContext?: {
            registerTool: (tool: unknown, options: unknown) => Promise<void>;
        };
    }).modelContext; if (!context)
        return; const lifecycle = new AbortController(); void Promise.resolve(context.registerTool({ name: 'read_simulated_pc', description: 'Consulta el hardware, fase, discos y tareas del PC simulado. No devuelve contraseñas.', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true }, execute: () => { const n = stateRef.current; return n ? { os: n.os, screen: n.screen, step: n.step, disk: n.disk, usb: n.usb, tasks: n.tasks } : { screen: 'selector' }; } }, { signal: lifecycle.signal })).catch(() => { }); return () => lifecycle.abort(); }, []);
    function choose(os: OS) { setSessions(prev => ({ ...prev, [os]: prev[os] || initial(os) })); setActive(os); }
    const progress = s?.job ? Math.max(0, Math.min(100, (now - s.job.start) / s.job.duration * 100)) : 0;
    function screen() { if (!s)
        return null; if (s.screen === 'preparation')
        return <Media s={s} edit={edit} confirm={confirm} progress={progress}/>; if (s.screen === 'installer')
        return s.os === 'windows' ? <WindowsInstaller s={s} edit={edit} confirm={confirm}/> : <UbuntuInstaller s={s} edit={edit} confirm={confirm}/>; if (s.screen === 'oobe')
        return <WindowsOobe s={s} edit={edit} progress={progress}/>; if (['desktop', 'live', 'existingWindows'].includes(s.screen))
        return <Desktop s={s} edit={edit} progress={progress}/>; if (['unlock', 'login'].includes(s.screen))
        return <UbuntuLogin key={s.screen} s={s} edit={edit}/>; if (s.screen === 'welcome')
        return <UbuntuWelcome s={s} edit={edit}/>; if (['installing', 'configuring', 'finishing'].includes(s.screen))
        return <div className={`install-progress ${s.os}`}><div>{s.os === 'windows' ? <WinMark /> : <b className="ubuntu-word">ubuntu</b>}<h2>{s.screen === 'installing' ? s.os === 'windows' ? 'Instalando Windows 11' : 'Instalando Ubuntu' : s.screen === 'configuring' ? 'Preparando dispositivos' : 'Un momento…'}</h2>{s.os === 'ubuntu' && <p>{progress < 30 ? 'Todo lo que necesitas para trabajar' : progress < 70 ? 'Un sistema abierto y personalizable' : 'Tu equipo, listo para empezar'}</p>}<Processing value={progress} label={s.screen !== 'installing' ? 'Aplicando la configuración…' : progress < 25 ? 'Preparando y copiando archivos…' : progress < 60 ? 'Instalando componentes y software…' : progress < 90 ? 'Configurando el sistema…' : 'Finalizando la instalación…'}/><p>No apagues el equipo.</p></div></div>; if (s.screen === 'installComplete')
        return <div className="ubuntu-setup"><section className="completion"><CheckCircle2 size={52}/><h2>Instalación completada</h2><p>Reinicia el equipo para utilizar la nueva instalación.</p><button className="primary" onClick={() => edit(n => { n.screen = 'removeMedia'; })}>Reiniciar ahora</button></section></div>; if (s.screen === 'removeMedia')
        return <div className="firmware dark-screen"><p>Please remove the installation medium, then press ENTER:</p><button onClick={() => key('Enter')}>Enter</button></div>; return <Hardware key={s.screen} s={s} edit={edit}/>; }
    return <main className="lab"><Localization language={s?.settings.language||'Español'}/><header className="lab-header"><div className="brand"><Monitor size={24}/><b>Instala<span>Lab</span></b><span className="brand-divider"/><span className="course">Digitalización · 4.º ESO</span></div><div className="header-actions">{s && !fixedOS && <button onClick={() => setActive(null)}><ArrowLeft size={16}/> Selector</button>}<button onClick={() => setInfo(true)}><BookOpen size={16}/><span>Acerca de la práctica</span></button></div></header>{saveError && <p className="save-warning">{saveError}</p>}
    {!s ? <section className="selector"><div className="eyebrow">LABORATORIO DE SISTEMAS</div><h1>Simulador de instalación<br />de sistemas operativos</h1><p className="selector-lead">Elige un sistema. Prepara el USB, arranca el equipo<br className="desktop-only"/> e instala y configura tu propio PC virtual.</p><div className="os-cards"><button className="os-card windows-card" onClick={() => choose('windows')}><div className="os-card-top"><WinMark /><span>01</span></div><h2>Windows 11</h2><p>Instalación limpia y configuración inicial</p><span className="card-action">{sessions.windows ? 'Continuar práctica' : 'Instalar Windows 11'} <span>↗</span></span></button><button className="os-card ubuntu-card" onClick={() => choose('ubuntu')}><div className="os-card-top"><span className="ubuntu-icon">◉</span><span>02</span></div><h2>Ubuntu Desktop</h2><p>26.04 LTS · Instalación y primer arranque</p><span className="card-action">{sessions.ubuntu ? 'Continuar práctica' : 'Instalar Ubuntu'} <span>↗</span></span></button></div><div className="selector-specs"><span><Monitor size={17}/> PC virtual UEFI</span><span>16 GB RAM</span><span>SSD 256 GB</span><span><Usb size={17}/> USB 16 GB</span></div><p className="simulation-note">Todo ocurre en la simulación. No se modifica tu ordenador ni se descargan sistemas reales.</p></section> : <><div className="workspace-heading"><div><span className={`os-dot ${active}`}/><b>{OS_NAMES[s.os]}</b><span className="subtle">/ {s.screen === 'preparation' ? 'Preparación del medio' : 'PC de destino'}</span></div><div><span className="saved">Guardado en este navegador</span><button onClick={() => confirm('¿Reiniciar simulación?', 'Se eliminarán todas las particiones, el usuario y el progreso de esta práctica. La otra práctica se conserva.', () => setSessions(prev => ({ ...prev, [s.os]: initial(s.os) })))}><RotateCcw size={15}/> Reiniciar simulación</button></div></div><div className={`workspace ${tasks ? '' : 'without-tasks'} ${s.os==='ubuntu'?'with-manual':''}`}>{s.os==='ubuntu'&&<CommandManual/>}<section className="machine-area"><div className="monitor-frame"><div className="monitor-top"><span>{s.screen === 'preparation' ? 'Equipo auxiliar' : HARDWARE.model}</span><div><button onClick={() => setTasks(!tasks)} aria-label="Mostrar u ocultar tareas"><ListChecks size={16}/></button><button onClick={() => document.querySelector('.monitor-frame')?.requestFullscreen?.()} aria-label="Pantalla completa"><Maximize2 size={16}/></button></div></div><div className="pc-screen" style={{'--accent':s.settings.accent==='blue'?'#1268ad':s.settings.accent==='green'?'#176c4b':'#ad3910'} as React.CSSProperties}>{loaded && screen()}{s.error && !['bootError'].includes(s.screen) && <div className="error-overlay" role="alert"><b>No se puede continuar</b><p>{s.error}</p><button onClick={() => edit(n => { n.error = ''; })}>Aceptar</button></div>}</div><div className="monitor-bottom"><span>SP EDUCATION</span><i className={s.screen === 'off' ? 'off' : ''}/></div></div><div className="hardware-controls"><div className="power-controls"><button aria-label="Encender o apagar PC" onClick={() => { const action = () => edit(n => power(n, n.screen === 'off' || n.screen === 'preparation')); if (s.job && s.job.kind !== 'post')
        confirm('¿Interrumpir el proceso?', 'El trabajo sin finalizar puede dejar el sistema sin arrancar. El SSD conservará los cambios realizados.', action);
    else
        action(); }}><Power size={17}/>{s.screen === 'off' || s.screen === 'preparation' ? 'Encender PC' : 'Apagar'}</button><button onClick={() => { const action = () => edit(n => power(n)); if (s.job && s.job.kind !== 'post')
        confirm('¿Reiniciar ahora?', 'Se interrumpirá el proceso que se está ejecutando.', action);
    else
        action(); }}><RotateCcw size={16}/> Reiniciar PC</button></div><div className="key-controls"><button disabled={s.screen !== 'post'} onClick={() => key('F2')}>F2 <span>UEFI</span></button><button disabled={s.screen !== 'post'} onClick={() => key('F12')}>F12 <span>Boot Menu</span></button></div></div><UsbBench s={s} edit={edit} confirm={confirm}/><div className="devices-strip"><Usb size={20}/><div><b>Kingston · 16 GB</b><small>{s.usb.location === 'pc' ? 'Conectado al PC de destino' : s.usb.location === 'helper' ? 'Conectado al equipo auxiliar' : 'Desconectado'}</small></div><button className={s.network ? 'connected' : ''} onClick={() => edit(n => { n.network = !n.network; })}><Wifi size={16}/>{s.network ? 'Red conectada' : 'Sin conexión'}</button>{s.screen !== 'preparation' && <button onClick={() => edit(n => { if (n.job)
        throw Error('Espera a que termine el proceso o apaga el equipo.'); n.screen = 'preparation'; })}>Equipo auxiliar</button>}</div></section>{tasks && <aside className="tasks-panel"><h2><ListChecks size={18}/> Tareas</h2><Practice s={s} edit={edit}/><div className="help-area"><button onClick={() => { setHelp(true); if (help)
        setHint(Math.min(2, hint + 1)); }}><HelpCircle size={17}/> {help && hint < 2 ? 'Otra pista' : 'Necesito ayuda'}</button>{help && <div className="hint"><small>PISTA {hint + 1} DE 3</small><p>{hints(s)[hint]}</p></div>}</div><details><summary>Equipo virtual <ChevronDown size={14}/></summary><p>{HARDWARE.cpu}<br />{HARDWARE.ram} GB RAM<br />{HARDWARE.ssdLabel}<br />UEFI · TPM 2.0 · Secure Boot</p></details>{s.os === 'ubuntu' && s.screen === 'preparation' && !s.tasks[2] && <details><summary>Escenarios opcionales</summary><Pick label="Estado inicial del SSD" value={s.scenario} options={[["clean", "Equipo limpio"], ["windows", "Windows y espacio libre"], ["bitlocker", "Windows con BitLocker"], ["rst", "Intel RST activado"]]} onChange={v => confirm('Cambiar escenario', 'Se reiniciará el progreso de Ubuntu para cargar este escenario.', () => edit(n => setScenario(n, v)))}/></details>}</aside>}</div><div className="workspace-footer"><span>Simulación educativa · Datos y credenciales ficticios</span><span>Las teclas también tienen botones para practicar desde cualquier dispositivo.</span></div></>}
    <AlertDialog open={!!confirmData} onOpenChange={open => { if (!open)
        setConfirmData(null); }}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>{confirmData?.title}</AlertDialogTitle><AlertDialogDescription>{confirmData?.text}</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => { const fn = confirmData?.action; setConfirmData(null); fn?.(); }}>Confirmar</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
    <Dialog open={info} onOpenChange={setInfo}><DialogContent className="info-dialog"><DialogTitle>InstalaLab · Referencias y alcance</DialogTitle><DialogDescription>Práctica local de instalación de sistemas operativos para Digitalización.</DialogDescription><p>Basado en documentación oficial consultada el 9 de octubre de 2026. Catálogo de actualizaciones educativo congelado, no conectado a servidores reales. Windows puede variar sus pantallas según la edición, la región y las actualizaciones del instalador.</p><p>El firmware es ficticio. Los tiempos, la red, los usuarios, el cifrado y las actualizaciones son simulados. Usa siempre contraseñas inventadas: el progreso se guarda en este navegador.</p><ul>{SOURCES.map(([name, url]) => <li key={url}><a href={url} target="_blank" rel="noreferrer">{name} ↗</a></li>)}</ul><p>Los tamaños EFI/recuperación son una configuración representativa, no una medida universal. LVM/ZFS se modelan como volúmenes simplificados; no se emula un kernel.</p><a href="/instalalab-fuentes.zip" download>Descargar código y guía técnica</a></DialogContent></Dialog></main>;
}
