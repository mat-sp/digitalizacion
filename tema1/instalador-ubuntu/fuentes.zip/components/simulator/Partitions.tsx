'use client';
import { useState } from 'react';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from '@/components/ui/table';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { capacity, extents, create, remove, format, type Disk } from '@/lib/sim/disk';
import { HARDWARE } from '@/lib/sim/config';
import type { Machine } from '@/lib/sim/machine';
import { type Edit, type Confirm, Field, Pick } from './ui';
export function Partitions({ s, edit, confirm, manual = false }: {
    s: Machine;
    edit: Edit;
    confirm: Confirm;
    manual?: boolean;
}) { const [adding, setAdding] = useState(false); const [size, setSize] = useState(''); const [fs, setFs] = useState(manual ? 'ext4' : 'NTFS'); const [mount, setMount] = useState('/'); const disk = manual ? (s.draft || s.disk) : s.disk; const rows = extents(disk); const chosen = rows.find(e => e.id === s.selection); const change = (fn: (d: Disk) => void) => edit(n => { if (manual && !n.draft)
    n.draft = structuredClone(n.disk); fn(manual ? n.draft! : n.disk); }); return <div className="partitions"><div className="disk-caption"><b>Disco 0 · {HARDWARE.ssdLabel}</b><span>GPT · {capacity(disk.size)}</span></div><div className="disk-bar">{rows.map(e => <div title={`${e.partition?.label || 'Sin asignar'} · ${capacity(e.size)}`} key={e.id} className={e.free ? 'free' : e.partition?.kind} style={{ flex: e.size }}/>)}</div><Table><TableHeader><TableRow><TableHead>Nombre</TableHead><TableHead>Tamaño</TableHead><TableHead>Libre</TableHead><TableHead>Tipo / formato</TableHead>{manual && <TableHead>Montaje</TableHead>}</TableRow></TableHeader><TableBody>{rows.map((e, i) => <TableRow key={e.id} tabIndex={0} onKeyDown={ev => { if (ev.key === 'Enter')
    edit(n => { n.selection = e.id; }); }} className={s.selection === e.id ? 'selected' : ''} onClick={() => edit(n => { n.selection = e.id; })}><TableCell>{e.free ? 'Disco 0 · Espacio sin asignar' : `Disco 0 · Partición ${i + 1}: ${e.partition?.label}`}</TableCell><TableCell>{capacity(e.size)}</TableCell><TableCell>{capacity(e.size - (e.partition?.used || 0))}</TableCell><TableCell>{e.free ? 'Sin asignar' : `${e.partition?.kind} · ${e.partition?.fs}`}</TableCell>{manual && <TableCell>{e.partition?.mount || '—'}</TableCell>}</TableRow>)}{s.usb.location === 'pc' && <TableRow tabIndex={0} className={s.selection === 'usb' ? 'selected' : ''} onClick={() => edit(n => { n.selection = 'usb'; })}><TableCell>Disco 1 · {HARDWARE.usbLabel}</TableCell><TableCell>{capacity(HARDWARE.usbMiB)}</TableCell><TableCell>{capacity(HARDWARE.usbMiB - 7000)}</TableCell><TableCell>USB · Medio de instalación</TableCell>{manual && <TableCell>—</TableCell>}</TableRow>}</TableBody></Table><div className="partition-actions"><button onClick={() => edit(n => { n.error = ''; })}>⟳ Actualizar</button><button disabled={!chosen?.free} onClick={() => { setSize(String(chosen?.size)); setAdding(true); }}>＋ Crear</button><button disabled={!chosen?.partition} onClick={() => confirm('Eliminar partición', 'Se perderán todos los datos de esta partición. Esta operación no se puede deshacer.', () => { change(d => remove(d, s.selection)); edit(n => { n.selection = ''; }); })}>Eliminar</button><button disabled={!chosen?.partition} onClick={() => confirm('Formatear partición', 'Se borrarán los archivos de la partición seleccionada.', () => change(d => format(d, s.selection, manual ? fs : 'NTFS', manual ? mount : '')))}>Formatear</button>{manual && <button disabled={!chosen?.partition} onClick={() => setAdding(true)}>Editar</button>}</div><p className="subtle">1 GiB = 1024 MiB. SSD comercial de 256 GB ≈ 238,42 GiB.{manual ? ' Los cambios se aplicarán al confirmar la instalación.' : ''}</p><Dialog open={adding} onOpenChange={setAdding}><DialogContent><DialogTitle>{chosen?.free ? 'Crear partición' : 'Editar partición'}</DialogTitle><DialogDescription>Configura el espacio seleccionado del SSD.</DialogDescription>{chosen?.free && <Field label="Tamaño (MiB)" type="number" value={size} onChange={setSize}/>}<Pick label="Sistema de archivos" value={fs} options={manual ? ['ext4', 'FAT32', 'swap', 'btrfs'] : ['NTFS']} onChange={setFs}/>{manual && <Pick label="Punto de montaje" value={mount} options={['/', '/home', '/boot', '/boot/efi', ['none', 'Sin montar']]} onChange={setMount}/>}<button className="primary" onClick={() => { change(d => { if (chosen?.free)
    create(d, chosen.start, Number(size), { kind: fs === 'FAT32' ? 'efi' : fs === 'swap' ? 'swap' : manual ? 'linux' : 'primary', fs, mount: manual && mount !== 'none' && fs !== 'swap' ? mount : '', label: manual ? 'Linux' : 'Nuevo volumen' });
else {
    const p = d.partitions.find(p => p.id === s.selection);
    if (p) {
        p.mount = mount === 'none' ? '' : mount;
        p.fs = fs;
        p.kind = fs === 'FAT32' ? 'efi' : fs === 'swap' ? 'swap' : 'linux';
    }
} }); setAdding(false); }}>Aplicar</button></DialogContent></Dialog></div>; }
