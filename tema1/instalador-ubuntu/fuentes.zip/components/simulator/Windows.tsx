'use client';
import { windowsNext, oobeNext } from '@/lib/sim/flows';
import { install, startJob, type Machine } from '@/lib/sim/machine';
import { windowsLayout } from '@/lib/sim/disk';
import { TIMING } from '@/lib/sim/config';
import { type Edit, type Confirm, Wizard, Pick, Field, Check, Choices, Processing, WinMark } from './ui';
import { Partitions } from './Partitions';
export const WINDOWS_STEPS = ['Seleccionar configuración de idioma', 'Seleccionar configuración de teclado', 'Seleccionar opción de instalación', 'Clave de producto', 'Seleccionar imagen', 'Avisos y términos de licencia aplicables', 'Seleccionar ubicación para instalar Windows 11', 'Listo para instalar'];
export function WindowsInstaller({ s, edit, confirm }: {
    s: Machine;
    edit: Edit;
    confirm: Confirm;
}) {
    const set = (k: string, v: string) => edit(n => { n.settings[k] = v; });
    function next() { edit(windowsNext); }
    return <div className="windows-setup"><Wizard title={WINDOWS_STEPS[s.step]} onBack={s.step > 0 ? () => edit(n => { n.step--; n.error = ''; }) : undefined} onNext={next} next={s.step === 5 ? 'Aceptar' : s.step === 7 ? 'Instalar' : 'Siguiente'}>
    {s.step === 0 && <><WinMark /><Pick label="Idioma que va a instalar" value={s.settings.language} options={['Español', 'English']} onChange={v => set('language', v)}/><Pick label="Formato de hora y moneda" value={s.settings.region} options={['España', 'México', 'United States']} onChange={v => set('region', v)}/></>}
    {s.step === 1 && <Pick label="Teclado o método de entrada" value={s.settings.keyboard} options={['Español', 'Latinoamericano', 'US']} onChange={v => set('keyboard', v)}/>}
    {s.step === 2 && <><Choices value={s.settings.setupOption || 'install'} options={[["install", "Instalar Windows 11"], ["repair", "Reparar mi PC"]]} onChange={v => set('setupOption', v)}/>{s.settings.setupOption === 'repair' ? <><p>Entorno de recuperación · No hay una instalación recuperable en el equipo limpio.</p><button onClick={() => set('setupOption', 'install')}>Volver a la instalación</button></> : <Check label="Acepto que se elimine todo, incluidos archivos, aplicaciones y configuración." checked={s.settings.eraseConsent === 'yes'} onChange={v => set('eraseConsent', v ? 'yes' : 'no')}/>}</>}
    {s.step === 3 && <><p>Si tienes una clave de producto, escríbela aquí.</p><Field label="Clave de producto simulada" value={s.settings.key || ''} onChange={v => set('key', v)} placeholder="XXXXX-XXXXX-XXXXX-XXXXX-XXXXX"/><button className="text-button" onClick={() => edit(n => { n.settings.key = ''; n.step++; })}>No tengo clave de producto</button><p className="subtle">No introduzcas una licencia real. La activación se simula.</p></>}
    {s.step === 4 && <Choices value={s.settings.edition} options={[["Home", "Windows 11 Home", "x64"], ["Pro", "Windows 11 Pro", "x64"]]} onChange={v => set('edition', v)}/>}
    {s.step === 5 && <div className="license"><h3>Términos de licencia del software de Microsoft</h3><p>Representación educativa de la pantalla de licencia. La instalación real exige aceptar el contrato de la edición correspondiente y disponer de una licencia válida para activarla.</p><p>Este simulador no instala ni distribuye software de Microsoft. Al pulsar Aceptar se registra únicamente la decisión dentro de esta práctica.</p><a href="https://www.microsoft.com/useterms" target="_blank" rel="noreferrer">Consultar los términos oficiales</a></div>}
    {s.step === 6 && <Partitions s={s} edit={edit} confirm={confirm}/>}
    {s.step === 7 && <><p>Has elegido:</p><div className="summary-row">✓ Instalar Windows 11 {s.settings.edition}</div><div className="summary-row">✓ No conservar nada</div><div className="summary-row">SSD interno · GPT · UEFI</div><p>El equipo se reiniciará varias veces durante la instalación.</p></>}
    </Wizard></div>;
}
export const OOBE_TITLES = ['¿Es este el país o región adecuado?', '¿Es la distribución del teclado adecuada?', '¿Quieres agregar una segunda distribución de teclado?', 'Vamos a conectarte a una red', 'Buscando actualizaciones', 'Vamos a asignar un nombre a tu dispositivo', 'Desbloquea tu experiencia de Microsoft', 'Escribir contraseña', 'Crear un PIN', 'Elegir la configuración de privacidad de tu dispositivo', 'Vamos a personalizar tu experiencia', 'Hacer una copia de seguridad de tus archivos con OneDrive', 'Prueba Microsoft 365', 'Todo listo'];
export function WindowsOobe({ s, edit, progress }: {
    s: Machine;
    edit: Edit;
    progress: number;
}) {
    const set = (k: string, v: string) => edit(n => { n.settings[k] = v; });
    function next() { edit(oobeNext); }
    return <div className="oobe"><div className="oobe-card"><div className="oobe-symbol"><WinMark /><span>{s.step < 3 ? '◎' : s.step < 5 ? '◉' : s.step < 9 ? '♙' : '✓'}</span></div><section><h2>{OOBE_TITLES[s.step]}</h2>
    {s.step === 0 && <Pick label="País o región" value={s.settings.region} options={['España', 'México', 'United States']} onChange={v => set('region', v)}/>}
    {s.step === 1 && <Pick label="Teclado" value={s.settings.keyboard} options={['Español', 'Latinoamericano', 'US']} onChange={v => set('keyboard', v)}/>}
    {s.step === 2 && <Pick label="Segundo teclado" value={s.settings.secondKeyboard || 'none'} options={[["none", "Omitir"], 'US', 'Español', 'Latinoamericano']} onChange={v => set('secondKeyboard', v)}/>}
    {s.step === 3 && <><div className="summary-row">Wi-Fi · Aula Digitalización <b>{s.network ? 'Conectado, seguro' : 'Desconectado'}</b></div><button onClick={() => edit(n => { n.network = !n.network; })}>{s.network ? 'Desconectar' : 'Conectar'}</button></>}
    {s.step === 4 && (s.job ? <Processing value={progress} label="Descargando actualizaciones importantes…"/> : <p>Vamos a comprobar las actualizaciones para tu dispositivo.</p>)}
    {s.step === 5 && <Field label="Nombre del dispositivo" value={s.user.host} onChange={v => edit(n => { n.user.host = v; })}/>}
    {s.step === 6 && <><p>Inicia sesión con tu cuenta Microsoft simulada.</p><Field label="Correo electrónico de práctica" value={s.user.login} onChange={v => edit(n => { n.user.login = v; })} placeholder="alumno@example.com"/><small>Utiliza alumno@example.com · No se envían datos a Microsoft.</small></>}
    {s.step === 7 && <><p>{s.user.login}</p><Field label="Contraseña de práctica" type="password" value={s.user.password} onChange={v => edit(n => { n.user.password = v; })}/><small>Cuenta del ejercicio: Practica123!</small></>}
    {s.step === 8 && <><Field label="Nuevo PIN" type="password" value={s.user.pin} onChange={v => edit(n => { n.user.pin = v; })}/><Field label="Confirmar PIN" type="password" value={s.user.confirm} onChange={v => edit(n => { n.user.confirm = v; })}/></>}
    {s.step === 9 && <div className="privacy-list">{[['location', 'Ubicación'], ['findDevice', 'Encontrar mi dispositivo'], ['diagnostics', 'Enviar datos de diagnóstico opcionales'], ['inking', 'Mejorar la escritura y la entrada manuscrita'], ['experiences', 'Experiencias personalizadas'], ['ads', 'Identificador de publicidad']].map(([k, t]) => <Check key={k} label={t} checked={s.settings[k] === 'yes'} onChange={v => set(k, v ? 'yes' : 'no')}/>)}</div>}
    {s.step === 10 && <Choices value={s.settings.usage || 'skip'} options={[["skip", "Omitir"], ["school", "Escuela"], ["creative", "Creatividad"], ["games", "Juegos"]]} onChange={v => set('usage', v)}/>}
    {s.step === 11 && <Choices value={s.settings.backup || 'local'} options={[["cloud", "Hacer copia de seguridad de mis archivos"], ["local", "Guardar archivos solo en este equipo"]]} onChange={v => set('backup', v)}/>}
    {s.step === 12 && <><p>Microsoft 365 Personal · Oferta simulada</p><Choices value={s.settings.trial || 'decline'} options={[["decline", "No, gracias"], ["accept", "Probar (simulado, sin compra)"]]} onChange={v => set('trial', v)}/></>}
    {s.step === 13 && <p>Estamos preparando tu cuenta. No apagues el equipo.</p>}
    <footer>{s.step > 0 && !s.job && <button onClick={() => edit(n => { n.step--; n.oobeStep = n.step; })}>Atrás</button>}<button className="primary" disabled={!!s.job} onClick={next}>{s.step === 9 ? 'Aceptar' : s.step === 2 && (s.settings.secondKeyboard || 'none') === 'none' ? 'Omitir' : 'Siguiente'}</button></footer></section></div></div>;
}
