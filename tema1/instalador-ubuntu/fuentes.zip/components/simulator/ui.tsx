'use client';
import type { ReactNode } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Progress } from '@/components/ui/progress';
import type { Machine } from '@/lib/sim/machine';
export type Edit = (fn: (s: Machine) => void) => void;
export type Confirm = (title: string, text: string, action: () => void) => void;
export function Pick({ label, value, options, onChange }: {
    label: string;
    value: string;
    options: (string | [
        string,
        string
    ])[];
    onChange: (v: string) => void;
}) { return <label className="field"><span>{label}</span><Select value={value} onValueChange={onChange}><SelectTrigger aria-label={label}><SelectValue /></SelectTrigger><SelectContent>{options.map(o => { const [v, t] = typeof o === 'string' ? [o, o] : o; return <SelectItem key={v} value={v}>{t}</SelectItem>; })}</SelectContent></Select></label>; }
export function Field({ label, value, onChange, type = 'text', placeholder = '', ...props }: {
    label: string;
    value: string;
    onChange: (v: string) => void;
    type?: string;
    placeholder?: string;
    min?: number;
    max?: number;
}) { return <label className="field"><span>{label}</span><input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} autoComplete="off" {...props}/></label>; }
export function Check({ label, checked, onChange }: {
    label: string;
    checked: boolean;
    onChange: (v: boolean) => void;
}) { return <label className="check"><Checkbox checked={checked} onCheckedChange={v => onChange(v === true)}/><span>{label}</span></label>; }
export function Choices({ value, options, onChange, disabledValues=[] }: {
    value: string;
    options: [
        string,
        string,
        string?
    ][];
    disabledValues?:string[];
    onChange: (v: string) => void;
}) { return <RadioGroup value={value} onValueChange={onChange} className="choices">{options.map(([v, title, sub]) => <label className={`choice ${value === v ? 'chosen' : ''}`} key={v}><RadioGroupItem value={v} disabled={disabledValues.includes(v)}/><span><strong>{title}</strong>{sub && <small>{sub}</small>}</span></label>)}</RadioGroup>; }
export function Wizard({ title, children, onNext, onBack, next = 'Siguiente', brand = 'windows', busy = false }: {
    title: string;
    children: ReactNode;
    onNext?: () => void;
    onBack?: () => void;
    next?: string;
    brand?: string;
    busy?: boolean;
}) { return <section className={`wizard ${brand}`}><div className="window-title">{brand === 'rufus' ? <><span>▣</span><span>Rufus · Preparación del USB</span></> : brand === 'ubuntu' ? <><span className="ubuntu-wordmark">ubuntu</span><span>Instalar Ubuntu</span><span aria-hidden="true">●</span></> : <><WinMark /><span>Configuración de Windows 11</span></>}</div><div className="wizard-body"><h2>{title}</h2>{children}</div><footer>{onBack && <button onClick={onBack}>{brand === 'ubuntu' ? '‹ Anterior' : 'Atrás'}</button>}<span />{onNext && <button className="primary" disabled={busy} onClick={onNext}>{next}</button>}</footer></section>; }
export function Processing({ value, label }: {
    value: number;
    label: string;
}) { return <div className="processing"><div className="spinner"/><p>{label}</p><Progress value={value}/><small>{Math.floor(value)} %</small></div>; }
export function WinMark() { return <span className="win-mark" aria-hidden="true"><i /><i /><i /><i /></span>; }
