'use client';
import { useState } from 'react';
import { HARDWARE, TIMING } from '@/lib/sim/config';
import { startJob, type Machine } from '@/lib/sim/machine';
import { type Edit, type Confirm, Wizard, Pick, Choices, Processing, WinMark } from './ui';
export function Media({ s, edit, confirm, progress }: {
    s: Machine;
    edit: Edit;
    confirm: Confirm;
    progress: number;
}) {
    const [tool, setTool] = useState(s.mediaStep > 0 || s.job?.kind === 'usb');
    const [target, setTarget] = useState('usb');
    const win = s.os === 'windows';
    const move = (step: number) => edit(n => { n.mediaStep = step; });
    return <div className="helper-desktop"><div className="helper-label">EQUIPO AUXILIAR <span>Preparación del medio</span></div>{!tool ? <div className="browser-window"><div className="browser-top"><span>◉　◉　◉</span><div>🔒 {win ? 'microsoft.com/es-es/software-download/windows11' : 'ubuntu.com/download/desktop'} <small>· Sitio simulado</small></div></div><nav>{win ? <><WinMark /> Microsoft</> : <b className="ubuntu-word">ubuntu</b>}<span>Descargas</span></nav><section><h2>{win ? 'Descargar Windows 11' : 'Ubuntu Desktop'}</h2><p>{win ? 'Crea un medio de instalación para otro equipo.' : 'Ubuntu Desktop 26.04 LTS · amd64'}</p><div className="download-card"><h3>{win ? 'Crear soportes de instalación de Windows 11' : 'Descarga la imagen de instalación'}</h3><p>{win ? 'La herramienta prepara una unidad flash USB o un archivo ISO.' : 'Archivo ISO para equipos Intel y AMD de 64 bits.'}</p><button className="primary" disabled={!!s.job || !s.network} onClick={() => edit(n => startJob(n, 'download', TIMING.download))}>{win ? 'Descargar herramienta ahora' : 'Descargar Ubuntu 26.04 LTS'}</button>{win && <button disabled={!!s.job} onClick={() => edit(n => startJob(n, 'iso', TIMING.download))}>Descargar imagen ISO</button>}</div>{s.job && <Processing value={progress} label="Descargando…"/>}{s.download && <div className="downloaded"><b>Descargas</b><p>▱ {s.download}</p><div className="button-row"><button onClick={() => { setTool(true); move(0); }}>Abrir {win ? 'Media Creation Tool' : 'Rufus'}</button><button onClick={() => edit(n => { if (!n.download.endsWith('.iso'))
            throw Error('Este archivo es una aplicación. Descarga primero la imagen ISO.'); if (n.usb.location !== 'helper')
            throw Error('Conecta el USB al equipo auxiliar.'); n.usb.files.push(n.download); n.usb.iso = true; })}>Copiar archivo al USB</button></div></div>}<p className="subtle">Todas las descargas y dispositivos pertenecen a la simulación.</p></section></div> : <Wizard brand={win ? 'windows' : 'rufus'} title={win ? ['Avisos y términos de licencia', 'Seleccionar idioma y edición', 'Elegir qué medio usar', 'Seleccionar unidad flash USB', 'Creando el medio de instalación', 'Tu unidad flash USB está lista'][s.mediaStep] : 'Rufus · Propiedades de la unidad'} onBack={s.mediaStep === 4 ? undefined : () => s.mediaStep > 0 ? move(s.mediaStep - 1) : setTool(false)} next={s.mediaStep === 5 ? 'Finalizar' : win ? 'Siguiente' : 'EMPEZAR'} busy={!!s.job} onNext={() => { if (s.mediaStep === 5) {
            setTool(false);
            return;
        } if (win && s.mediaStep === 2 && s.settings.mediaType === 'iso') {
            edit(n => { n.mediaStep = 0; startJob(n, 'iso', TIMING.download); });
            setTool(false);
            return;
        } if (win && s.mediaStep < 3) {
            move(s.mediaStep + 1);
            return;
        } if (s.usb.location !== 'helper') {
            edit(() => { throw Error('No se detecta ninguna unidad USB. Conéctala al equipo auxiliar.'); });
            return;
        } if (target !== 'usb') {
            edit(() => { throw Error('El disco del equipo auxiliar está en uso. No se puede sobrescribir.'); });
            return;
        } if (!win && !s.settings.selectedIso) {
            edit(() => { throw Error('Pulsa SELECCIONAR y abre la imagen ISO descargada.'); });
            return;
        } if (!win && !s.download.endsWith('.iso')) {
            edit(() => { throw Error('Selecciona una imagen ISO.'); });
            return;
        } confirm('Se borrará el contenido del USB', `${!win?'Imagen ISOHybrid: se escribirá en modo imagen ISO recomendado. ' : ''}${HARDWARE.usbLabel}: se eliminarán todos los archivos, incluido Trabajo-clase.pdf.`, () => edit(n => { n.settings.hybridConfirmed='yes'; n.usb.files = []; n.usb.bootable = false; n.mediaStep = 4; startJob(n, 'usb', TIMING.usb); })); }}>
        {win && s.mediaStep === 0 && <p>Herramienta de creación de medios de Windows 11. Para preparar el soporte es necesario aceptar los términos de uso. Esta pantalla reproduce la aceptación; no concede ninguna licencia de Windows.</p>}
        {win && s.mediaStep === 1 && <><Pick label="Idioma" value={s.settings.language} options={['Español', 'English']} onChange={v => edit(n => { n.settings.language = v; })}/><Pick label="Edición" value="Windows 11" options={['Windows 11']} onChange={() => { }}/><p>Arquitectura: 64 bits (x64)</p></>}
        {win && s.mediaStep === 2 && <Choices value={s.settings.mediaType || 'usb'} options={[["usb", "Unidad flash USB", "Necesitas una unidad de al menos 8 GB."], ["iso", "Archivo ISO", "Guarda la imagen para grabarla después."]]} onChange={v => edit(n => { n.settings.mediaType = v; })}/>}
        {((win && s.mediaStep === 3) || !win) && s.mediaStep !== 4 && s.mediaStep !== 5 && <><Pick label="Dispositivo" value={target} options={[["usb", `E: ${HARDWARE.usbLabel}`], ["helper", "C: SSD del equipo auxiliar (en uso)"]]} onChange={setTarget}/>{!win && <><button onClick={() => edit(n => { n.settings.selectedIso = n.download; })}>SELECCIONAR imagen ISO</button><p>{s.settings.selectedIso || 'Ninguna imagen seleccionada'}</p><Pick label="Selección de arranque" value={s.download || 'none'} options={s.download ? [s.download] : [['none', 'Selecciona una ISO']]} onChange={() => { }}/><Pick label="Esquema de partición" value="GPT" options={['GPT']} onChange={() => { }}/><p>Sistema de destino: UEFI (no CSM)</p><p>Modo de escritura: imagen ISO (recomendado)</p></>}<p>Se eliminarán los archivos de la unidad seleccionada.</p></>}
        {s.mediaStep === 4 && <Processing value={progress} label={progress < 40 ? 'Descargando y preparando…' : progress < 90 ? 'Escribiendo el medio de instalación…' : 'Verificando la unidad USB…'}/>}{s.mediaStep === 5 && <><h3>✓ USB de instalación preparado</h3><p>{HARDWARE.usbLabel}</p><p>El soporte contiene un cargador UEFI y los archivos de instalación.</p></>}
        </Wizard>}<div className="helper-taskbar">▦ <span>Explorador de archivos</span><span>{s.usb.location === 'helper' ? `E: ${s.usb.files.join(' · ')}` : 'USB no conectado a este equipo'}</span></div></div>;
}
