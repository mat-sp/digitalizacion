'use client';
import { useState } from 'react';
import { HARDWARE } from '@/lib/sim/config';
import { boot, enterInstaller, power, type Machine } from '@/lib/sim/machine';
import { type Edit, Pick, Check, Field } from './ui';
export function Hardware({ s, edit }: {
    s: Machine;
    edit: Edit;
}) {
    const [fw, setFw] = useState(s.firmware);
    if (s.screen === 'off')
        return <div className="firmware dark-screen"><p className="muted">Sin señal</p><button onClick={() => edit(n => power(n))}>Encender el PC</button></div>;
    if (s.screen === 'post')
        return <div className="firmware dark-screen"><h1 className="pc-logo">SP<span>EDUCATION</span></h1><p>UEFI firmware · Inicializando dispositivos…</p><div className="post-keys"><button onClick={() => edit(n => { n.job = null; n.screen = 'uefi'; })}>F2 · UEFI Setup</button><button onClick={() => edit(n => { n.job = null; n.screen = 'bootMenu'; })}>F12 · Boot Menu</button></div></div>;
    if (s.screen === 'uefi')
        return <div className="uefi"><header><b>SP UEFI SETUP UTILITY</b><span>{HARDWARE.firmware}</span></header><h2>System & Boot</h2><div className="uefi-grid"><section><h3>System Information</h3><dl><dt>Product Name</dt><dd>{HARDWARE.model}</dd><dt>Processor</dt><dd>{HARDWARE.cpu}</dd><dt>Memory</dt><dd>{HARDWARE.ram} GB DDR4</dd><dt>Storage</dt><dd>{HARDWARE.ssdLabel} · GPT</dd><dt>USB</dt><dd>{s.usb.location === 'pc' ? HARDWARE.usbLabel : 'Not detected'}</dd><dt>Boot mode</dt><dd>UEFI</dd></dl></section><section><Field label="System date / time" type="datetime-local" value={fw.clock} onChange={v => setFw({ ...fw, clock: v })}/><Pick label="Boot Option #1" value={fw.first} options={[["ssd", "SSD / OS Boot Manager"], ["usb", "UEFI: Kingston USB"]]} onChange={v => setFw({ ...fw, first: v as 'ssd' | 'usb' })}/><Check label="Secure Boot" checked={fw.secure} onChange={v => setFw({ ...fw, secure: v })}/><Check label="TPM 2.0 / Intel PTT" checked={fw.tpm} onChange={v => setFw({ ...fw, tpm: v })}/><Pick label="Storage controller" value={fw.rst ? 'rst' : 'ahci'} options={[["ahci", "AHCI"], ["rst", "Intel RST"]]} onChange={v => setFw({ ...fw, rst: v === 'rst' })}/></section></div><footer><button onClick={() => edit(n => power(n))}>Discard changes & Exit</button><button onClick={() => edit(n => { n.firmware = fw; power(n); })}>Save changes & Exit</button></footer></div>;
    if (s.screen === 'dualBoot')
        return <div className="firmware"><div className="boot-list"><h2>GNU GRUB</h2><button onClick={() => edit(n => boot(n, 'ssd', true))}>Ubuntu</button><button onClick={() => edit(n => { n.screen = 'existingWindows'; })}>Windows Boot Manager</button><button onClick={() => edit(n => { n.screen = 'uefi'; })}>UEFI Firmware Settings</button></div></div>;
    if (s.screen === 'bootMenu')
        return <div className="firmware"><div className="boot-list"><h2>Boot Manager</h2><p>Select a boot device</p><button onClick={() => edit(n => boot(n, 'ssd'))}>{s.installed === 'windows' ? 'Windows Boot Manager' : s.installed === 'ubuntu' ? 'ubuntu' : HARDWARE.ssdLabel} <small>NVMe · Internal SSD</small></button>{s.usb.location === 'pc' && <button onClick={() => edit(n => boot(n, 'usb'))}>UEFI: {HARDWARE.usbLabel}<small>USB removable device</small></button>}<button onClick={() => edit(n => { n.screen = 'uefi'; })}>Enter Setup</button></div></div>;
    if (s.screen === 'usbPrompt')
        return <div className="firmware dark-screen"><p>Press any key to boot from USB . . .</p><button onClick={() => edit(enterInstaller)}>Pulsar una tecla</button>{s.installed && <button onClick={() => edit(n => boot(n, 'ssd'))}>Continuar desde el SSD</button>}</div>;
    if (s.screen === 'grub')
        return <div className="firmware"><div className="boot-list"><h2>GNU GRUB</h2><button onClick={() => edit(enterInstaller)}>Try or Install Ubuntu</button><button onClick={() => edit(n => { n.settings.safeGraphics = 'yes'; enterInstaller(n); })}>Ubuntu (safe graphics)</button><button onClick={() => edit(n => boot(n, 'ssd'))}>Boot from next volume</button><button onClick={() => edit(n => { n.screen = 'uefi'; })}>UEFI Firmware Settings</button></div></div>;
    return <div className="firmware dark-screen"><h2>Boot Device Not Found</h2><p>{s.error}</p><button onClick={() => edit(n => power(n))}>Reiniciar</button><button onClick={() => edit(n => { n.screen = 'preparation'; n.error = ''; })}>Volver al equipo auxiliar</button></div>;
}
