'use client';
import {useEffect} from 'react';
import {translate} from '@/lib/sim/i18n';
export function Localization({language}:{language:string}){
 useEffect(()=>{
 const originals=new Map<Text,{source:string;shown:string}>();
 const attrs=new Map<Element,Map<string,{source:string;shown:string}>>();
 let queued=false;let disposed=false;
 function run(){if(disposed)return;queued=false;observer.disconnect();document.querySelectorAll('.pc-screen,[role="listbox"],[data-slot="select-content"],[role="dialog"]:not(.info-dialog),[role="alertdialog"]').forEach(root=>{
 const walk=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let node:Node|null;
 while((node=walk.nextNode())){const t=node as Text;if(t.parentElement?.closest('pre,code,textarea,script,style'))continue;const old=originals.get(t);const source=old&&t.data===old.shown?old.source:t.data;const shown=language==='English'?translate(source):source;if(t.data!==shown)t.data=shown;originals.set(t,{source,shown});}
 root.querySelectorAll('[placeholder],[aria-label]').forEach(el=>{for(const key of ['placeholder','aria-label']){const value=el.getAttribute(key);if(!value)continue;let map=attrs.get(el);if(!map){map=new Map();attrs.set(el,map);}const old=map.get(key);const source=old&&value===old.shown?old.source:value;const shown=language==='English'?translate(source):source;if(value!==shown)el.setAttribute(key,shown);map.set(key,{source,shown});}});
 });observer.observe(document.body,{subtree:true,childList:true,characterData:true});}
 const observer=new MutationObserver(()=>{if(!queued){queued=true;queueMicrotask(run);}});run();
 return()=>{disposed=true;observer.disconnect();originals.forEach(({source,shown},node)=>{if(node.data===shown)node.data=source;});attrs.forEach((map,el)=>map.forEach(({source,shown},key)=>{if(el.getAttribute(key)===shown)el.setAttribute(key,source);}));};
 },[language]);return null;
}
