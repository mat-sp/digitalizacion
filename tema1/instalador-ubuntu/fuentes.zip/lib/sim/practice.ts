import {TASKS as TASKS_FOR_ORDER} from './config';
import type { Machine } from './machine';
export const WINDOWS_VERSION = '26H2';
export const WINDOWS_BUILD = '26300';
export function record(s:Machine,id:string){s.settings['done_'+id]='yes';}
export const POST_TASKS = [
 ['version','Consulta la versión instalada y el hardware'],
 ['storage','Identifica EFI, raíz/sistema y espacio disponible'],
 ['network','Comprueba la conexión y su dirección IP'],
 ['time','Configura Madrid y sincronización automática'],
 ['keyboard','Comprueba el teclado español'],
 ['display','Configura pantalla y conserva los cambios (confirmación)'],
 ['sound','Selecciona salida y ajusta volumen al 40 %'],
 ['notifications','Activa No molestar / desactiva los avisos emergentes'],
 ['energy','Configura el modo de energía equilibrado'],
 ['theme','Activa la apariencia oscura'],
 ['restart','Reinicia y comprueba el arranque sin USB'],
] as const;
export function checklist(s:Machine){return POST_TASKS.map(([id,label])=>({id,label,done:s.settings['done_'+id]==='yes'}));}
export function completed(s:Machine){return s.tasks.every(Boolean)&&checklist(s).every(x=>x.done)&&[0,1,2].every(i=>(s.settings['answer'+i]||'').trim().length>=25);}
export const QUESTIONS = ['Explica por qué copiar la ISO al USB no basta para arrancar el instalador.', 'Identifica la partición EFI y la del sistema. ¿Qué función tiene cada una?', 'Explica qué comprobaste tras actualizar y qué diferencia hay entre buscar e instalar actualizaciones.'];
export const COMMANDS = [
 ['Identidad y versión','cat /etc/os-release','Muestra la versión de Ubuntu.'],
 ['Hardware','lscpu','Procesador y arquitectura.'],
 ['Memoria','free -h','Memoria RAM e intercambio.'],
 ['Discos','lsblk -f','Particiones, sistemas de archivos y montajes.'],
 ['Espacio','df -h','Uso de los sistemas de archivos montados.'],
 ['Red','ip addr','Interfaces y direcciones IPv4/IPv6.'],
 ['Wi-Fi','nmcli device status','Estado de los dispositivos de red.'],
 ['Redes disponibles','nmcli device wifi list','Busca puntos de acceso.'],
 ['Conectar','nmcli device wifi connect "Aula Digitalizacion" password "Aula2026!"','Credenciales ficticias del laboratorio.'],
 ['Comprobar conexión','ping -c 4 ubuntu.com','Cuatro peticiones de prueba.'],
 ['Índices','sudo apt update','Actualiza la lista de paquetes disponibles; no instala actualizaciones.'],
 ['Paquetes pendientes','apt list --upgradable','Consulta lo que puede actualizarse.'],
 ['Instalar actualizaciones','sudo apt upgrade','Instala paquetes; confirma con S.'],
 ['Fecha y zona','timedatectl','Consulta reloj y sincronización.'],
 ['Zona horaria','sudo timedatectl set-timezone Europe/Madrid','Establece Madrid.'],
 ['Sincronizar','sudo timedatectl set-ntp true','Activa sincronización automática.'],
 ['Teclado','gsettings set org.gnome.desktop.input-sources sources "[(\'xkb\', \'es\')]"','Distribución española de la sesión GNOME.'],
 ['Pantalla','gnome-control-center display','Abre el panel de pantalla: resolución y escalado se ajustan visualmente en Wayland.'],
 ['Sonido','wpctl status','Lista dispositivos de audio.'],
 ['Salida predeterminada','wpctl set-default 42','Selecciona los altavoces del PC virtual.'],
 ['Volumen','wpctl set-volume @DEFAULT_AUDIO_SINK@ 0.4','40 % en la salida predeterminada.'],
 ['Ver volumen','wpctl get-volume @DEFAULT_AUDIO_SINK@','Comprueba el valor aplicado.'],
 ['Notificaciones','gsettings set org.gnome.desktop.notifications show-banners false','Desactiva avisos emergentes.'],
 ['Energía','powerprofilesctl set balanced','Perfil equilibrado.'],
 ['Ver perfil','powerprofilesctl get','Comprueba el perfil activo.'],
 ['Apariencia','gsettings set org.gnome.desktop.interface color-scheme prefer-dark','Preferencia oscura.'],
 ['Color de énfasis','gsettings set org.gnome.desktop.interface accent-color blue','Puedes usar blue, green u orange.'],
 ['Reinicio','sudo reboot','Reinicia el PC virtual; retira antes el USB.'],
] as const;
export function orderedTasks(s:Machine){
 const installation=TASKS_FOR_ORDER.map((label,i)=>({id:'install'+i,label,done:!!s.tasks[i],phase:i===5?'post':'installation'}));
 const post=checklist(s).map(t=>({...t,phase:'post'}));
 const all=[...installation,...post];
 const visible=s.tasks[2]?all:all.filter(t=>t.phase==='installation');
 return visible.sort((a,b)=>Number(a.done)-Number(b.done));
}
