import {HARDWARE, TIMING} from './config';
import {power, startJob, type Machine} from './machine';
import {capacity} from './disk';
import {record} from './practice';
export type Result = {text:string; confirm?:boolean; panel?:string};
export function execute(s:Machine,raw:string):Result {
 const cmd=raw.trim().replace(/\s+/g,' '); const base=cmd.replace(/^sudo /,'');
 const out=(text:string):Result=>({text});
 const done=(id:string,text='')=>{record(s,id);return out(text)};
 if(s.screen==='live' && /^(apt|reboot|gsettings|timedatectl set|powerprofilesctl set|wpctl set)/.test(base))return out('La práctica de configuración requiere instalar primero Ubuntu en el SSD.');
 if(base==='reboot'){power(s);return out('Reiniciando…');}
 if(base==='cat /etc/os-release'||base==='lsb_release -a')return done('version','NAME="Ubuntu"\nVERSION="26.04 LTS (Resolute Raccoon)"\nVERSION_ID="26.04"');
 if(base==='uname -a')return out(`Linux ${s.user.host} 7.0.0-generic #Ubuntu SMP x86_64 GNU/Linux`);
 if(base==='hostnamectl')return out(`Static hostname: ${s.user.host}\nOperating System: Ubuntu 26.04 LTS\nArchitecture: x86-64`);
 if(base==='lscpu')return out(`Architecture: x86_64\nCPU(s): 12\nCore(s) per socket: 6\nModel name: Intel Core i5-12400`);
 if(base==='free -h')return out('               total    used    free   available\nMem:           16Gi    2.0Gi    14Gi       14Gi\nSwap:          4.0Gi      0B   4.0Gi');
 if(base==='lsblk'||base==='lsblk -f')return done('storage','NAME           FSTYPE    SIZE       MOUNTPOINTS\nnvme0n1                  '+capacity(s.disk.size)+'\n'+s.disk.partitions.map((p,i)=>`  nvme0n1p${i+1}    ${p.fs}    ${capacity(p.size)}    ${p.mount}`).join('\n')+(s.usb.location==='pc'?'\nsda            vfat      14.9 GiB   /media/usb':''));
 if(base==='df -h')return done('storage','Filesystem       Size       Used       Avail     Mounted on\n'+s.disk.partitions.filter(p=>p.mount).map((p)=>`/dev/nvme0n1p${s.disk.partitions.indexOf(p)+1}  ${capacity(p.size)}  ${capacity(p.used)}  ${capacity(p.size-p.used)}  ${p.mount}`).join('\n'));
 if(base==='ip addr'||base==='ip a')return done('network',`1: lo: <LOOPBACK,UP>\n    inet 127.0.0.1/8\n2: wlp1s0: <${s.network?'BROADCAST,MULTICAST,UP,LOWER_UP':'NO-CARRIER,BROADCAST,MULTICAST,UP'}>\n${s.network?'    inet 192.168.1.42/24\n    inet6 2001:db8:1::42/64 (dirección de documentación)':''}`);
 if(base==='nmcli device status')return out(`DEVICE  TYPE  STATE  CONNECTION\nwlp1s0  wifi  ${s.network?'connected  Aula Digitalizacion':'disconnected  --'}`);
 if(base==='nmcli device wifi list')return out('SSID                 SIGNAL  SECURITY\nAula Digitalizacion  92      WPA2\nInvitados            65      WPA2');
 if(base==='nmcli device disconnect wlp1s0'){s.network=false;return out('Device wlp1s0 successfully disconnected.');}
 if(base.startsWith('nmcli device wifi connect')){if(!/^nmcli device wifi connect ["']Aula Digitalizacion["'] password ["']Aula2026!["']$/.test(base))return out('Error: red o contraseña incorrecta. Consulta las credenciales de práctica.');s.network=true;return out('Device wlp1s0 successfully activated.');}
 if(base==='ping -c 4 ubuntu.com')return out(s.network?'4 packets transmitted, 4 received, 0% packet loss\nrtt min/avg/max = 12/18/23 ms':'ping: ubuntu.com: Temporary failure in name resolution');
 if(base==='apt update'){if(!s.network)return out('Err: Temporary failure resolving archive.ubuntu.com');s.settings.aptIndex='yes';startJob(s,'check',6000);return out('Obteniendo índices de archive.ubuntu.com…');}
 if(base==='apt list --upgradable')return out(s.tasks[5]?'Listing... Done':s.settings.aptIndex==='yes'?'Listing... Done\nlinux-generic/resolute-updates [upgradable]\nubuntu-desktop/resolute-updates [upgradable]\n10 paquetes adicionales (catálogo simulado)':'Ejecuta apt update para renovar los índices.');
 if(base==='apt upgrade'){if(!s.network)return out('Error temporal al resolver archive.ubuntu.com');if(s.settings.aptIndex!=='yes')return out('Actualiza primero los índices con sudo apt update.');if(s.tasks[5])return out('0 actualizados, 0 nuevos, 0 para eliminar.');return {text:'12 actualizados, 0 nuevos, 0 para eliminar.\nSe descargarán 128 MB. ¿Desea continuar? [S/n]',confirm:true};}
 if(base==='timedatectl')return out(`Time zone: ${s.settings.timezone}\nSystem clock synchronized: ${s.settings.autoTime!=='no'?'yes':'no'}\nNTP service: ${s.settings.autoTime!=='no'?'active':'inactive'}`);
 if(base==='timedatectl set-timezone Europe/Madrid'){s.settings.timezone='Europe/Madrid';s.settings.zoneSet='yes';if(s.settings.ntpSet==='yes')record(s,'time');return out('');}
 if(base==='timedatectl set-ntp true'){s.settings.autoTime='yes';s.settings.ntpSet='yes';if(s.settings.zoneSet==='yes')record(s,'time');return out('');}
 if(base.startsWith('gsettings set org.gnome.desktop.input-sources sources ')){if(!base.includes("[('xkb', 'es')]"))return out('Valor no admitido: usa la sintaxis GVariant del manual.');s.settings.keyboard='Español';return done('keyboard');}
 if(base==='gnome-control-center display')return {text:'',panel:'system'};
 if(base==='wpctl status')return out('Audio\n Sinks:\n   42. Altavoces integrados [vol: '+(Number(s.settings.volume||70)/100).toFixed(2)+']\n   43. HDMI / DisplayPort\n Sources:\n   51. Micrófono integrado');
 if(base==='wpctl set-default 42'){s.settings.output='Altavoces';s.settings.outputSet='yes';if(s.settings.volume==='40')record(s,'sound');return out('');}
 if(base==='wpctl set-volume @DEFAULT_AUDIO_SINK@ 0.4'||base==='wpctl set-volume @DEFAULT_SINK@ 0.4'){s.settings.volume='40';if(s.settings.outputSet==='yes')record(s,'sound');return out('');}
 if(base==='wpctl get-volume @DEFAULT_AUDIO_SINK@'||base==='wpctl get-volume @DEFAULT_SINK@')return out('Volume: '+(Number(s.settings.volume||70)/100).toFixed(2));
 if(base==='gsettings set org.gnome.desktop.notifications show-banners false'){s.settings.notifications='no';return done('notifications');}
 if(base==='gsettings get org.gnome.desktop.notifications show-banners')return out(s.settings.notifications==='no'?'false':'true');
 if(base==='powerprofilesctl list')return out('power-saver\nbalanced\nperformance');
 if(base==='powerprofilesctl get')return out(s.settings.energy||'balanced');
 if(base==='powerprofilesctl set balanced'){s.settings.energy='balanced';return done('energy');}
 if(base==='gsettings set org.gnome.desktop.interface color-scheme prefer-dark'){s.settings.theme='dark';return done('theme');}
 if(/^gsettings set org.gnome.desktop.interface accent-color (blue|green|orange)$/.test(base)){s.settings.accent=base.split(' ').at(-1)!;return out('');}
 if(base==='gsettings get org.gnome.desktop.interface color-scheme')return out(s.settings.theme==='dark'?"'prefer-dark'":"'default'");
 if(base==='whoami')return out(s.user.login);
 if(base==='pwd')return out('/home/'+s.user.login);
 return out(`${base.split(' ')[0]}: orden o argumentos no implementados en esta terminal educativa. Consulta el manual de comandos de la práctica.`);
}
export function privileged(cmd:string){return /^(sudo )?(apt (update|upgrade)|timedatectl set-|reboot)/.test(cmd.trim());}
export function upgrade(s:Machine){if(!s.network)throw Error('No hay conexión. Vuelve a conectar la red.');startJob(s,'update',TIMING.update);}
