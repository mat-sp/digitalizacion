import type {Machine} from './machine';
export function audit(before:Machine,after:Machine){
 const lines:string[]=[];
 if(before.screen!==after.screen||before.step!==after.step)lines.push(`Pantalla: ${before.screen} (${before.step+1}) → ${after.screen} (${after.step+1})`);
 if(before.usb.location!==after.usb.location)lines.push(`USB: ${before.usb.location} → ${after.usb.location}`);
 if(before.network!==after.network)lines.push(`Red: ${after.network?'conectada':'desconectada'}`);
 if(before.updateStatus!==after.updateStatus)lines.push(`Actualizaciones: ${before.updateStatus} → ${after.updateStatus}`);
 for(const [key,value] of Object.entries(after.settings)){if(before.settings[key]===value||key.startsWith('answer')||key.startsWith('done_')||['student','key','keyboardTest'].includes(key))continue;lines.push(`Ajuste ${key}: ${before.settings[key]??'sin establecer'} → ${value}`);}
 for(const [key,value] of Object.entries(after.user)){if(before.user[key]===value)continue;lines.push(['password','confirm','pin','encryption','encryptionConfirm'].includes(key)?`Credencial ${key}: modificada (contenido oculto)`:`Cuenta ${key}: ${value}`);}
 if(JSON.stringify(before.disk)!==JSON.stringify(after.disk))lines.push('Disco: '+after.disk.partitions.map(p=>`${p.label} · ${p.fs} · ${p.size} MiB · ${p.mount||'sin montaje'}`).join(' / '));
 after.tasks.forEach((v,i)=>{if(v!==before.tasks[i])lines.push(`Tarea instalación ${i+1}: ${v?'cumplida':'pendiente'}`);});
 for(const key of Object.keys(after.settings))if(key.startsWith('done_')&&after.settings[key]!==before.settings[key])lines.push(`Objetivo ${key.slice(5)}: cumplido`);
 const time=new Date().toLocaleTimeString('es-ES');after.history.push(...lines.map(x=>`${time} · ${x}`));
}
