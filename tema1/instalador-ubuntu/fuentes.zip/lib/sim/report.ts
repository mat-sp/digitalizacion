import type {Machine} from './machine';
import {TASKS,HARDWARE,OS_NAMES} from './config';
import {checklist,QUESTIONS,completed} from './practice';
function escapePDF(s:string){return s.replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');}
function latin(s:string){const map:Record<string,string>={'→':'->','←':'<-','✓':'OK','×':'x','—':'-','–':'-','’':"'",'“':'"','”':'"','…':'...','€':'EUR','\u00a0':' '};return [...s].map(c=>map[c]??(c.charCodeAt(0)<=255?c:'?')).join('');}
function wrap(s:string){const lines:string[]=[];for(const raw of latin(s).split('\n')){let line='';for(const word of raw.split(/\s+/)){if((line+' '+word).length>90&&line){lines.push(line);line='';}if(word.length>90){if(line){lines.push(line);line='';}for(let i=0;i<word.length;i+=90)lines.push(word.slice(i,i+90));}else line+=(line?' ':'')+word;}lines.push(line);}return lines;}
export function reportLines(s:Machine){
 const rows:string[]=[];const add=(text='')=>rows.push(...wrap(text));
 add('ALUMNO/A: '+(s.settings.student||'Sin nombre'));add('SISTEMA: '+OS_NAMES[s.os]);add('FECHA DEL INFORME: '+new Date().toLocaleString('es-ES'));add('ESTADO: '+(completed(s)?'Práctica completada':'Práctica incompleta'));add();
 add('01  CHECKLIST DE INSTALACIÓN');TASKS.forEach((t,i)=>add(`[${s.tasks[i]?'CUMPLIDO':'PENDIENTE'}] ${t}`));add();add('02  CHECKLIST DE CONFIGURACIÓN');checklist(s).forEach(t=>add(`[${t.done?'CUMPLIDO':'PENDIENTE'}] ${t.label}`));
 add();add('03  REFLEXIONES DEL ALUMNO/A');QUESTIONS.forEach((q,i)=>{add(q);add(s.settings['answer'+i]||'SIN RESPUESTA');add((s.settings['answer'+i]||'').trim().length>=25?'Registrada. Requiere valoración docente.':'Pendiente o insuficientemente desarrollada.');add();});
 add('04  ESTADO FINAL DEL EQUIPO');add(`${HARDWARE.model} | ${HARDWARE.cpu} | RAM ${HARDWARE.ram} GB`);add(`SSD ${s.disk.size} MiB | Tabla ${s.disk.table} | USB ${s.usb.location} | Arrancable ${s.usb.bootable?'sí':'no'}`);add(`Usuario: ${s.user.login} | Equipo: ${s.user.host}`);add(`Red: ${s.network?'conectada':'desconectada'} | Actualizaciones: ${s.updateStatus}`);
 for(const key of ['language','keyboard','timezone','autoTime','resolution','scale','theme','accent','volume','output','notifications','energy','windowsVersion','windowsBuild','updateRevision'])if(s.settings[key])add(`${key}: ${s.settings[key]}`);
 s.disk.partitions.forEach(p=>add(`Partición: ${p.label} | ${p.size} MiB | ${p.fs} | ${p.mount||'sin montaje'}`));add();
 add('05  HISTORIAL DE ACCIONES E INCIDENCIAS');add('Registro disponible desde esta versión. No incluye contraseñas ni PIN.');if(!s.history.length)add('No hay acciones registradas.');s.history.forEach(line=>{let clean=line;for(const secret of [s.user.password,s.user.encryption,'Practica123!'])if(secret&&secret.length>=4)clean=clean.split(secret).join('[oculta]');add(clean);});add();add('Los indicadores reflejan acciones realizadas; las respuestas necesitan revisión del docente. Todo corresponde al equipo simulado.');return rows;
}
export function makeReport(s:Machine):Uint8Array{
 const lines=reportLines(s);const pages:string[][]=[];for(let i=0;i<lines.length;i+=50)pages.push(lines.slice(i,i+50));
 const objs:string[]=[];const add=(v:string)=>{objs.push(v);return objs.length;};
 add('<< /Type /Catalog /Pages 2 0 R >>');add('');add('<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>');add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');const ids:number[]=[];
 pages.forEach((rows,index)=>{const text=`q 0.08 0.18 0.24 rg 0 778 595 64 re f Q\nBT /F2 19 Tf 1 1 1 rg 48 804 Td (INSTALALAB | INFORME DE PRACTICA) Tj ET\nBT /F1 9 Tf 0.12 0.17 0.22 rg 13 TL 48 748 Td\n${rows.map((r,i)=>`${i?'T* ':''}(${escapePDF(r)}) Tj`).join('\n')}\nET\nBT /F1 8 Tf 0.4 0.4 0.4 rg 48 42 Td (Digitalizacion - ${s.os.toUpperCase()} | Pagina ${index+1} de ${pages.length}) Tj ET`;
 const content=add(`<< /Length ${text.length} >>\nstream\n${text}\nendstream`);ids.push(add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${content} 0 R >>`));});
 objs[1]=`<< /Type /Pages /Count ${ids.length} /Kids [${ids.map(id=>id+' 0 R').join(' ')}] >>`;
 let pdf='%PDF-1.4\n';const offsets=[0];objs.forEach((obj,i)=>{offsets.push(pdf.length);pdf+=`${i+1} 0 obj\n${obj}\nendobj\n`;});const xref=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`+offsets.slice(1).map(x=>String(x).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<< /Size ${objs.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return Uint8Array.from(pdf,c=>c.charCodeAt(0));
}
export function downloadReport(s:Machine){const bytes=makeReport(s);const url=URL.createObjectURL(new Blob([bytes as BlobPart],{type:'application/pdf'}));const a=document.createElement('a');a.href=url;a.download=`Informe_${s.os}.pdf`;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
