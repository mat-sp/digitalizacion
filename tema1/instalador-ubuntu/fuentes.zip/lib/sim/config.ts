export type OS = 'windows' | 'ubuntu';
export const HARDWARE = { model: 'SP Education 260', cpu: 'Intel Core i5-12400 · 6 núcleos · x86-64', ram: 16, ssdMiB: 244140, ssdLabel: 'SP NVMe 256 GB', usbMiB: 15258, usbLabel: 'Kingston DataTraveler 16 GB', sector: 512, firmware: 'SP UEFI 2.6', network: 'Intel Wi-Fi 6 AX201' };
export const TIMING = { post: 5000, download: 6000, usb: 15000, install: 35000, configure: 10000, update: 12000 };
export const OS_NAMES = { windows: 'Windows 11', ubuntu: 'Ubuntu Desktop 26.04 LTS' };
export const TASKS = ['Prepara el medio de instalación', 'Arranca desde el USB', 'Instala el sistema en el SSD', 'Configura la cuenta de usuario', 'Completa la configuración inicial', 'Comprueba y aplica las actualizaciones'];
export const SOURCES = [
    ['Instalación limpia de Windows 11', 'https://support.microsoft.com/es-es/windows/deployment/install-upgrade/reinstall-windows-with-the-installation-media'],
    ['Medios de Windows 11', 'https://www.microsoft.com/es-es/software-download/windows11'],
    ['Particiones UEFI/GPT', 'https://learn.microsoft.com/es-es/windows-hardware/manufacture/desktop/configure-uefigpt-based-hard-drive-partitions?view=windows-11'],
    ['Configuración inicial de Windows', 'https://learn.microsoft.com/en-us/windows-hardware/customize/desktop/customize-oobe-in-windows-11'],
    ['Instalar Ubuntu Desktop 26.04', 'https://ubuntu.com/desktop/docs/en/26.04/tutorial/install-ubuntu-desktop/']
];
