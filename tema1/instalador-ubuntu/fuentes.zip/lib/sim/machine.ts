import {record,WINDOWS_VERSION,WINDOWS_BUILD} from './practice';
import { HARDWARE, TIMING, type OS } from './config.ts';
import { type Disk, windowsLayout, ubuntuLayout, validateUbuntu, create } from './disk.ts';
export type Machine = {
    version: number;
    os: OS;
    screen: string;
    step: number;
    disk: Disk;
    draft: Disk | null;
    usb: {
        location: 'helper' | 'pc' | 'none';
        bootable: boolean;
        iso: boolean;
        files: string[];
    };
    firmware: {
        secure: boolean;
        tpm: boolean;
        first: 'ssd' | 'usb';
        rst: boolean;
        clock: string;
    };
    network: boolean;
    installed: OS | null;
    installState: 'none' | 'copying' | 'configuring' | 'ready';
    rootId: string;
    user: Record<string, string>;
    settings: Record<string, string>;
    tasks: boolean[];
    mediaStep: number;
    download: string;
    job: null | {
        kind: string;
        start: number;
        duration: number;
    };
    selection: string;
    history: string[];
    updateStatus: string;
    oobeStep: number;
    error: string;
    scenario: string;
    bitlocker: boolean;
};
export function initial(os: OS): Machine { return { version: 1, os, screen: 'preparation', step: 0, disk: { size: HARDWARE.ssdMiB, table: 'GPT', partitions: [] }, draft: null, usb: { location: 'helper', bootable: false, iso: false, files: ['Trabajo-clase.pdf'] }, firmware: { secure: true, tpm: true, first: 'ssd', rst: false, clock: '2026-10-01T11:00' }, network: true, installed: null, installState: 'none', rootId: '', user: { name: '', host: 'SP-PC', login: '', password: '', confirm: '', pin: '', encryption: '', encryptionConfirm: '' }, settings: { language: 'Español', region: 'España', keyboard: 'Español', timezone: 'Europe/Madrid', edition: 'Home', diskMode: 'erase', encryption: 'none', apps: 'default', loginRequired: 'yes', location: 'no', telemetry: 'no', theme: 'light', accent: os==='windows'?'blue':'orange', resolution: '1920 × 1080', method: 'interactive', volume:'70', output:'Altavoces', energy:'balanced', notifications:'yes', scale:'100', windowsVersion:WINDOWS_VERSION, windowsBuild:WINDOWS_BUILD, updateRevision:'Inicial', lockScreen:'5', sleep:'15' }, tasks: Array(6).fill(false), mediaStep: 0, download: '', job: null, selection: '', history: [], updateStatus: 'unchecked', oobeStep: 0, error: '', scenario: 'clean', bitlocker: false }; }
export function log(s: Machine, text: string) { s.history = [...s.history, text]; }
export function startJob(s: Machine, kind: string, duration: number) { s.job = { kind, start: Date.now(), duration }; }
export function power(s: Machine, on = true) { if (s.job?.kind === 'install') {
    s.installState = 'none';
    s.installed = null;
    log(s, 'Instalación interrumpida. Los datos escritos permanecen en el SSD.');
} s.job = null; s.error = ''; s.screen = on ? 'post' : 'off'; if (on)
    startJob(s, 'post', TIMING.post); }
export function boot(s: Machine, device: 'usb' | 'ssd', skipMenu = false) { s.job = null; s.error = ''; if (device === 'ssd' && !s.tasks[2] && ['windows', 'bitlocker'].includes(s.scenario)) {
    s.screen = 'existingWindows';
    return;
} if (device === 'usb') {
    if (s.usb.location !== 'pc' || !s.usb.bootable) {
        s.screen = 'bootError';
        s.error = 'No bootable device found. El dispositivo no contiene un cargador UEFI válido.';
        return;
    }
    s.screen = s.os === 'windows' ? 'usbPrompt' : 'grub';
    return;
} const root = s.disk.partitions.find(p => p.id === s.rootId); if (!s.installed || !root?.os || !s.disk.partitions.some(p => p.kind === 'efi' && p.bootable)) {
    s.screen = 'bootError';
    s.error = 'Boot Device Not Found. Please install an operating system on your hard disk.';
    return;
} if (s.installed === 'ubuntu' && s.disk.partitions.some(p => p.os === 'windows') && !skipMenu) {
    s.screen = 'dualBoot';
    return;
} if (s.installed === 'windows') {
    if (s.installState === 'configuring') {
        s.screen = 'configuring';
        startJob(s, 'configure', TIMING.configure);
    }
    else if (!s.tasks[4]) {
        s.screen = 'oobe';
        s.step = s.oobeStep;
    }
    else {
        s.screen = 'desktop';
        if(s.usb.location==='none')record(s,'restart');
        if (s.updateStatus === 'restart') {
            s.updateStatus = 'current';
            s.tasks[5] = true; s.settings.updateRevision='Actualización de calidad del laboratorio aplicada';
        }
    }
}
else {
    s.screen = (['passphrase', 'zfscrypt'].includes(s.settings.encryption) || (s.settings.encryption === 'hardware' && (!s.firmware.tpm || !s.firmware.secure))) ? 'unlock' : s.settings.loginRequired === 'yes' ? 'login' : s.tasks[4] ? 'desktop' : 'welcome';
    s.step = 0; if(s.screen==='desktop' && s.usb.location==='none')record(s,'restart');
} }
export function enterInstaller(s: Machine) { s.tasks[1] = true; s.screen = 'installer'; s.step = 0; s.selection = ''; s.draft = null; log(s, 'Arranque desde el medio USB.'); }
export function install(s: Machine) { if (s.usb.location !== 'pc' || !s.usb.bootable)
    throw Error('No se encuentra el medio de instalación. Conecta de nuevo el USB.'); if (s.os === 'windows') {
    if (!s.firmware.tpm || !s.firmware.secure)
        throw Error('Este equipo no cumple los requisitos: activa TPM 2.0 y Secure Boot en UEFI.');
    if (s.selection === 'usb')
        throw Error('Windows no se puede instalar en una unidad conectada mediante USB.');
    s.rootId = windowsLayout(s.disk, s.selection);
}
else {
    if(!s.user.name.trim()||!s.user.login||s.user.password.length<4||s.user.password!==s.user.confirm)throw Error('Crea tu cuenta y confirma tu contraseña antes de instalar Ubuntu.');
    if (s.firmware.rst)
        throw Error('Intel RST está activado. Cambia el controlador a AHCI antes de instalar Ubuntu.');
    if (s.settings.diskMode === 'alongside' && s.bitlocker)
        throw Error('BitLocker está activado. Desactiva el cifrado desde Windows o elige borrar el disco.');
    if (s.settings.diskMode === 'manual') {
        if (!s.draft)
            throw Error('No se ha configurado el disco.');
        const p = validateUbuntu(s.draft);
        s.disk = structuredClone(s.draft);
        const root = s.disk.partitions.find(x => x.id === p.id)!;
        root.os = 'ubuntu';
        root.used = 12000;
            const efi = s.disk.partitions.find(p=>p.kind==='efi'); if(efi) efi.bootable=true;
        s.rootId = root.id;
    }
    else
        s.rootId = ubuntuLayout(s.disk, s.settings.diskMode, s.settings.encryption);
    s.tasks[3] = true;
} s.installed = null; for(const k of Object.keys(s.settings))if(k.startsWith('done_')||k.startsWith('answer')||['aptIndex','zoneSet','ntpSet','outputSet'].includes(k))delete s.settings[k]; s.tasks[2] = false; s.tasks[4] = false; s.tasks[5] = false; s.oobeStep = 0; s.updateStatus = 'unchecked'; s.installState = 'copying'; s.screen = 'installing'; startJob(s, 'install', TIMING.install); log(s, 'Comienza la escritura del sistema en el SSD.'); }
export function finishJob(s: Machine) { const kind = s.job?.kind; s.job = null; if (kind && ['download', 'iso', 'oobeUpdate', 'check', 'update'].includes(kind) && !s.network) {
    s.error = 'No hay conexión de red. Conéctate e inténtalo de nuevo.';
    return;
} if (kind === 'post') {
    boot(s, s.firmware.first === 'usb' && s.usb.location === 'pc' ? 'usb' : 'ssd');
} if (kind === 'download') {
    s.download = s.os === 'windows' ? 'MediaCreationTool.exe' : 'ubuntu-26.04-desktop-amd64.iso';
} if (kind === 'iso') {
    s.download = s.os === 'windows' ? 'Win11_x64.iso' : 'ubuntu-26.04-desktop-amd64.iso';
} if (kind === 'usb') {
    s.usb.bootable = true;
    s.usb.iso = false;
    s.usb.files = s.os === 'windows' ? ['EFI', 'boot', 'sources', 'setup.exe'] : ['EFI', 'boot', 'casper'];
    s.tasks[0] = true;
    s.mediaStep = 5;
} if (kind === 'install') {
    s.installed = s.os;
    s.tasks[2] = true;
    if (s.os === 'windows') {
        s.installState = 'configuring';
        power(s);
    }
    else {
        s.installState = 'ready';
        s.screen = 'installComplete';
    }
} if (kind === 'configure') {
    s.installState = 'ready';
    power(s);
} if (kind === 'oobeUpdate') {
    s.step++;
    s.oobeStep = s.step;
} if (kind === 'finalize') {
    s.tasks[4] = true;
    s.screen = 'desktop';
} if (kind === 'check') {
    s.updateStatus = s.tasks[5] ? 'current' : 'available';
} if (kind === 'update') {
    s.updateStatus = s.os === 'windows' ? 'restart' : 'current';
    if (s.os === 'ubuntu')
        s.tasks[5] = true;
} }
export function setScenario(s: Machine, scenario: string) { const n = initial(s.os); Object.assign(s, n); s.scenario = scenario; if (scenario === 'rst')
    s.firmware.rst = true; if (scenario === 'windows' || scenario === 'bitlocker') {
    create(s.disk, 0, 260, { kind: 'efi', fs: 'FAT32', label: 'Sistema EFI' });
    create(s.disk, 260, 16, { kind: 'msr', fs: '—', label: 'MSR' });
    const p = create(s.disk, 276, 140000, { label: 'Windows', used: 50000, os: 'windows' });
    create(s.disk, 140276, 1024, { kind: 'recovery', label: 'Recuperación', used: 740 });
    s.rootId = p.id;
    s.bitlocker = scenario === 'bitlocker';
} }
