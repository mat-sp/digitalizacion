import {record} from './practice';
import { install, startJob, power, type Machine } from './machine.ts';
import { windowsLayout, validateUbuntu } from './disk.ts';
import { TIMING } from './config.ts';
export function windowsNext(n: Machine) { if (n.step === 2 && n.settings.setupOption === 'repair')
    throw Error('Estás en recuperación. Vuelve a Instalar Windows 11 para realizar una instalación limpia.'); if (n.step === 2 && n.settings.eraseConsent !== 'yes')
    throw Error('Confirma que se eliminarán los archivos, aplicaciones y configuración.'); if (n.step === 3 && n.settings.key && !/^([A-Z0-9]{5}-){4}[A-Z0-9]{5}$/i.test(n.settings.key))
    throw Error('La clave debe tener 25 caracteres, en cinco grupos. Puedes continuar sin clave.'); if (n.step === 6) {
    if (n.selection === 'usb')
        throw Error('Windows no se puede instalar en una unidad USB.');
    windowsLayout(structuredClone(n.disk), n.selection);
} if (n.step === 7) {
    install(n);
    return;
} n.step++; }
export function oobeNext(n: Machine) { if (n.step === 3 && !n.network)
    throw Error('Necesitas una conexión a Internet para continuar. Conéctate a una red.'); if (n.step === 4) {
    startJob(n, 'oobeUpdate', TIMING.download);
    return;
} if (n.step === 5 && !/^[A-Za-z0-9-]{1,15}$/.test(n.user.host))
    throw Error('El nombre debe tener entre 1 y 15 letras, números o guiones.'); if (n.step === 6 && !/^[^@\s]+@example\.(com|org)$/.test(n.user.login))
    throw Error('Usa una cuenta ficticia terminada en @example.com o @example.org.'); if (n.step === 7) {
    if (n.user.password !== 'Practica123!')
        throw Error('Contraseña de práctica: Practica123!');
    n.user.name = n.user.login.split('@')[0];
} if (n.step === 8) {
    if (!/^\d{4,}$/.test(n.user.pin) || n.user.pin !== n.user.confirm)
        throw Error('Los PIN deben coincidir y contener al menos cuatro dígitos.');
    n.tasks[3] = true;
} if (n.step === 13) {
    n.screen = 'finishing';
    startJob(n, 'finalize', TIMING.configure);
    return;
} n.step++; n.oobeStep = n.step; }
export function ubuntuNext(n: Machine) { if (n.step === 4) {
    if (n.settings.try === 'yes') {
        n.screen = 'live';
        return;
    }
    if (n.firmware.rst)
        throw Error('Desactiva Intel RST. Ubuntu necesita que el controlador esté en modo AHCI. Reinicia y entra en UEFI.');
} if (n.step === 5 && n.settings.method === 'automated') {
    throw Error('La instalación automatizada está desactivada en esta práctica. Selecciona Instalación interactiva.');
} if (n.step === 8) {
    if (n.settings.diskMode === 'alongside' && n.bitlocker)
        throw Error('BitLocker está activado. No es posible instalar Ubuntu junto a Windows hasta desactivar el cifrado.');
    if (n.settings.diskMode === 'manual') {
        validateUbuntu(n.draft || n.disk);
        n.settings.encryption = 'none';
        n.step = 10;
        return;
    }
    if (n.settings.diskMode === 'alongside') {
        n.settings.encryption = 'none';
        n.step = 10;
        return;
    }
} if (n.step === 9) {
    if (['passphrase', 'zfscrypt'].includes(n.settings.encryption) && (n.user.encryption.length < 8 || n.user.encryption !== n.user.encryptionConfirm))
        throw Error('Las contraseñas de cifrado deben coincidir y tener al menos ocho caracteres.');
    if (n.settings.encryption === 'hardware' && (!n.firmware.secure || !n.firmware.tpm))
        throw Error('El cifrado respaldado por hardware requiere TPM 2.0 y Secure Boot activos.');
} if (n.step === 10) {
    if (!n.user.name.trim() || !/^[a-z][a-z0-9_-]*$/.test(n.user.login) || !/^[A-Za-z0-9-]+$/.test(n.user.host))
        throw Error('Completa el nombre, el equipo y un usuario válido en minúsculas.');
    if (n.user.password.length < 4 || n.user.password !== n.user.confirm)
        throw Error('Las contraseñas no coinciden o tienen menos de cuatro caracteres.');
} if (n.step === 12) {
    return;
} n.step++; }
export function authenticateUbuntu(n: Machine, password: string) { const unlock = n.screen === 'unlock'; const recovery = n.settings.encryption === 'hardware'; const expected = unlock ? recovery ? '2604-1600-2560-2026' : n.user.encryption : n.user.password; if (password !== expected)
    throw Error(unlock ? 'No se ha podido desbloquear el disco.' : 'La contraseña no es correcta. Inténtalo de nuevo.'); n.screen = unlock ? n.settings.loginRequired === 'yes' ? 'login' : n.tasks[4] ? 'desktop' : 'welcome' : n.tasks[4] ? 'desktop' : 'welcome'; n.step = 0; if(n.screen==='desktop'&&n.usb.location==='none')record(n,'restart'); }
export function welcomeNext(n: Machine) { if (n.step === 4) {
    n.tasks[4] = true;
    n.screen = 'desktop';
}
else
    n.step++; }
export function removeMediaAndReboot(n: Machine) { if (n.usb.location === 'pc')
    throw Error('Retira el medio de instalación antes de continuar.'); power(n); }
