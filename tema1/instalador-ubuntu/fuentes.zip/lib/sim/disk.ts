export type Partition = {
    id: string;
    start: number;
    size: number;
    kind: 'efi' | 'msr' | 'primary' | 'recovery' | 'linux' | 'swap';
    fs: string;
    label: string;
    mount: string;
    used: number;
    os?: string;
    bootable?: boolean;
};
export type Disk = {
    size: number;
    table: 'GPT';
    partitions: Partition[];
};
export type Extent = {
    id: string;
    start: number;
    size: number;
    free?: boolean;
    partition?: Partition;
};
export function extents(d: Disk): Extent[] { const out: Extent[] = []; let cursor = 0; for (const p of [...d.partitions].sort((a, b) => a.start - b.start)) {
    if (p.start > cursor)
        out.push({ id: `free-${cursor}`, start: cursor, size: p.start - cursor, free: true });
    out.push({ id: p.id, start: p.start, size: p.size, partition: p });
    cursor = p.start + p.size;
} if (cursor < d.size)
    out.push({ id: `free-${cursor}`, start: cursor, size: d.size - cursor, free: true }); return out; }
export function validate(d: Disk) { let end = 0; for (const p of [...d.partitions].sort((a, b) => a.start - b.start)) {
    if (!Number.isInteger(p.size) || p.size <= 0 || p.start < end || p.start + p.size > d.size || p.used > p.size)
        throw Error('La tabla de particiones no es válida.');
    end = p.start + p.size;
} return true; }
export function create(d: Disk, start: number, size: number, fields: Partial<Partition> = {}) { if (!Number.isInteger(size) || size < 1)
    throw Error('Escribe un tamaño válido en MiB.'); const free = extents(d).find(e => e.free && e.start <= start && e.start + e.size >= start + size); if (!free)
    throw Error('No hay suficiente espacio contiguo sin asignar.'); const p: Partition = { id: `p-${start}-${Date.now()}-${d.partitions.length}`, start, size, kind: 'primary', fs: 'NTFS', label: 'Nuevo volumen', mount: '', used: 0, ...fields }; d.partitions.push(p); validate(d); return p; }
export function remove(d: Disk, id: string) { d.partitions = d.partitions.filter(p => p.id !== id); validate(d); }
export function format(d: Disk, id: string, fs: string, mount = '') { const p = d.partitions.find(p => p.id === id); if (!p)
    throw Error('Selecciona una partición.'); p.fs = fs; p.mount = mount; p.used = 0; delete p.os;
    delete p.bootable; }
export function windowsLayout(d: Disk, id: string) { const e = extents(d).find(e => e.id === id); if (!e)
    throw Error('Selecciona una ubicación para instalar Windows.'); if (e.size < 65536)
    throw Error('Windows necesita un destino de al menos 64 GiB en este equipo.'); if (!e.free && e.partition?.kind !== 'primary')
    throw Error('Windows no se puede instalar en esta partición del sistema.'); if (!e.free && e.partition?.fs !== 'NTFS')
    throw Error('Windows se debe instalar en una partición NTFS.'); if (!e.free) {
    remove(d, e.id);
} let start = e.start; let size = e.size; if (!d.partitions.some(p => p.kind === 'efi')) {
    create(d, start, 260, { kind: 'efi', fs: 'FAT32', label: 'Sistema EFI' });
    start += 260;
    size -= 260;
} if (!d.partitions.some(p => p.kind === 'msr')) {
    create(d, start, 16, { kind: 'msr', fs: '—', label: 'Reservada de Microsoft' });
    start += 16;
    size -= 16;
} const root = create(d, start, size - 1024, { label: 'Windows', os: 'windows', used: 24000 }); create(d, start + size - 1024, 1024, { kind: 'recovery', label: 'Recuperación', used: 740 }); const efi = d.partitions.find(p=>p.kind==='efi'); if(efi) efi.bootable=true;
    return root.id; }
export function ubuntuLayout(d: Disk, mode: string, encrypted: string) { if (mode === 'erase') {
    d.partitions = [];
    create(d, 0, 1024, { kind: 'efi', fs: 'FAT32', mount: '/boot/efi', label: 'Sistema EFI' });
} const e = extents(d).filter(e => e.free && e.size >= 25600).sort((a, b) => b.size - a.size)[0]; if (!e)
    throw Error('Ubuntu necesita al menos 25 GiB de espacio libre contiguo.'); let start = e.start, size = e.size; if (!d.partitions.some(p => p.kind === 'efi')) {
    create(d, start, 1024, { kind: 'efi', fs: 'FAT32', mount: '/boot/efi', label: 'Sistema EFI' });
    start += 1024;
    size -= 1024;
} if (['passphrase', 'zfscrypt', 'hardware'].includes(encrypted)) {
    create(d, start, 2048, { kind: 'linux', fs: 'ext4', mount: '/boot', label: 'Arranque' });
    start += 2048;
    size -= 2048;
} const efi = d.partitions.find(p=>p.kind==='efi'); if(efi) efi.bootable=true;
    return create(d, start, size, { kind: 'linux', fs: encrypted === 'zfs' || encrypted === 'zfscrypt' ? 'ZFS' + (encrypted === 'zfscrypt' ? ' cifrado' : '') : encrypted === 'lvm' ? 'LVM / ext4' : ['passphrase', 'hardware'].includes(encrypted) ? 'LUKS2 / LVM / ext4' : 'ext4', mount: '/', label: 'Ubuntu', os: 'ubuntu', used: 12000 }).id; }
export function validateUbuntu(d: Disk) { const roots = d.partitions.filter(p => p.mount === '/'); if (roots.length !== 1 || roots[0].size < 25600 || !['ext4', 'btrfs'].includes(roots[0].fs))
    throw Error('Selecciona una única raíz / de al menos 25 GiB con sistema ext4 o btrfs.'); if (!d.partitions.some(p => p.kind === 'efi' && p.fs === 'FAT32' && p.size >= 100))
    throw Error('Falta una partición EFI FAT32 de al menos 100 MiB.'); const mounts = d.partitions.map(p => p.mount).filter(Boolean); if (new Set(mounts).size !== mounts.length)
    throw Error('Un punto de montaje no puede estar repetido.'); return roots[0]; }
export const capacity = (m: number) => m >= 1024 ? `${(m / 1024).toFixed(2)} GiB` : `${m} MiB`;
