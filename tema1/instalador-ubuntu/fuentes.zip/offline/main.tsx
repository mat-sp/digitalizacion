import React from 'react';
import {createRoot} from 'react-dom/client';
import Simulator from '../components/simulator/Simulator';
import '../app/globals.css';
import '../app/os-interfaces.css';
declare const __PRACTICE_OS__: 'windows'|'ubuntu';
createRoot(document.getElementById('root')!).render(<Simulator fixedOS={__PRACTICE_OS__}/>);
