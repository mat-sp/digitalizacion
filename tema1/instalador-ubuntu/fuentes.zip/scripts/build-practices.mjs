import {build} from 'vite';
import react from '@vitejs/plugin-react';
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
const root=process.cwd();
for(const os of ['windows','ubuntu']){
 const out=path.join(root,'outputs/practices',os);
 await build({configFile:false,root,plugins:[react(),{name:'local-links',transform(code,id){if(id.endsWith('/components/simulator/Simulator.tsx'))return code.replace('href="/instalalab-fuentes.zip"','href="./fuentes.zip"');}}],resolve:{alias:{'@':root}},define:{'process.env.NODE_ENV':'"production"','__PRACTICE_OS__':JSON.stringify(os)},publicDir:false,build:{outDir:out,emptyOutDir:true,lib:{entry:path.join(root,'offline/main.tsx'),name:'InstalaLab',formats:['iife'],fileName:()=> 'simulador.js'},cssCodeSplit:false,assetsInlineLimit:10000000,minify:true,sourcemap:false}});
 const files=await readdir(out); const js=await readFile(path.join(out,'simulador.js'),'utf8'); const css=await readFile(path.join(out,files.find(x=>x.endsWith('.css'))),'utf8');
 new vm.Script(js);if(/\bimport\s*\(/.test(js)||/@import\s|url\(\s*['"]?(?!data:|#)/.test(css))throw Error('Dependencia externa inesperada');
 const name=os==='windows'?'Windows 11':'Ubuntu Desktop 26.04 LTS';
 const html=`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>InstalaLab · ${name}</title><style>${css.replaceAll('</style','<\\/style')}</style></head><body><div id="root"></div><noscript>Activa JavaScript para utilizar el simulador.</noscript><script>${js.replaceAll('</script','<\\/script')}</script></body></html>`;
 await writeFile(path.join(out,'index.html'),html);
 console.log('VALIDADO HTML autónomo '+os+': '+Buffer.byteLength(html)+' bytes');
}
