import ts from 'typescript';
import fs from 'node:fs/promises';
import {existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
export async function resolve(specifier,context,nextResolve){if(specifier.startsWith('@/'))specifier=pathToFileURL(path.join(process.cwd(),specifier.slice(2))).href;if(specifier.startsWith('.')||specifier.startsWith('file:')){const url=new URL(specifier,context.parentURL);const file=fileURLToPath(url);for(const ext of ['', '.ts','.tsx','.js'])if(existsSync(file+ext)&&!(await fs.stat(file+ext)).isDirectory())return {url:pathToFileURL(file+ext).href,shortCircuit:true};}return nextResolve(specifier,context);}
export async function load(url,context,nextLoad){if(/\.(tsx|ts)$/.test(url)){const source=await fs.readFile(fileURLToPath(url),'utf8');return {format:'module',source:ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText,shortCircuit:true}}return nextLoad(url,context)}
