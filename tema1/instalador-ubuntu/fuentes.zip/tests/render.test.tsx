import React from 'react';
import {renderToString} from 'react-dom/server';
import {initial} from '../lib/sim/machine';
import {WindowsInstaller,WindowsOobe} from '../components/simulator/Windows';
import {UbuntuInstaller,UbuntuLogin,UbuntuWelcome} from '../components/simulator/Ubuntu';
import {Hardware} from '../components/simulator/Hardware';
import {Media} from '../components/simulator/Media';
import {Desktop} from '../components/simulator/Desktop';
import {Practice,UsbBench} from '../components/simulator/Practice';
import Simulator from '../components/simulator/Simulator';
const edit=()=>{};const confirm=()=>{};let count=0;
function check(el:React.ReactNode,label:string){const html=renderToString(el);if(html.length<100||html.includes('undefined'))throw Error('Render inválido: '+label);count++;}
check(<Simulator/>,'selector');
for(const os of ['windows','ubuntu'] as const){const s=initial(os);s.usb.location='pc';s.user.name='Alumno';s.user.login='alumno';s.user.password='practica';for(const screen of ['off','post','uefi','bootMenu','bootError','usbPrompt','grub']){s.screen=screen;check(<Hardware s={s} edit={edit}/>,screen);}for(let step=0;step<=5;step++){s.mediaStep=step;check(<Media s={s} edit={edit} confirm={confirm} progress={42}/>,os+' medio '+step);}s.screen='installer';for(let step=0;step<(os==='windows'?8:13);step++){s.step=step;check(os==='windows'?<WindowsInstaller s={s} edit={edit} confirm={confirm}/>:<UbuntuInstaller s={s} edit={edit} confirm={confirm}/>,os+' installer '+step);}if(os==='windows'){s.screen='oobe';for(let step=0;step<14;step++){s.step=step;check(<WindowsOobe s={s} edit={edit} progress={44}/>,os+' oobe '+step);}}else{for(const screen of ['unlock','login']){s.screen=screen;check(<UbuntuLogin s={s} edit={edit}/>,screen);}s.screen='welcome';for(let step=0;step<5;step++){s.step=step;check(<UbuntuWelcome s={s} edit={edit}/>,os+' welcome '+step);}}s.screen='desktop';check(<Desktop s={s} edit={edit} progress={40}/>,os+' desktop');}
for(const os of ['windows','ubuntu'] as const){const s=initial(os);s.screen='desktop';check(<Practice s={s} edit={edit}/>,os+' checklist');check(<UsbBench s={s} edit={edit} confirm={confirm}/>,os+' USB');for(const section of ['system','sound','notifications','energy','network','appearance','language','time','storage','about','updates'])check(<Desktop s={s} edit={edit} progress={40} initialApp='settings' initialSection={section}/>,os+' settings '+section);check(<Desktop s={s} edit={edit} progress={40} initialApp='terminal'/>,os+' terminal');}
console.log(`PASS: ${count} pantallas renderizadas sin excepciones.`);
