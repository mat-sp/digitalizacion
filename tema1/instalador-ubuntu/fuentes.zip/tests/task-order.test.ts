import {strict as a} from 'node:assert';
import {initial} from '../lib/sim/machine';
import {orderedTasks,checklist} from '../lib/sim/practice';
for(const os of ['windows','ubuntu'] as const){const s=initial(os);a.equal(s.tasks.length+checklist(s).length,17);a.equal(orderedTasks(s).length,5);s.tasks[0]=true;a.equal(orderedTasks(s)[0].id,'install1');a.equal(orderedTasks(s).at(-1)?.id,'install0');s.tasks[1]=true;s.tasks[2]=true;s.tasks[3]=true;s.tasks[4]=true;a.equal(orderedTasks(s).length,17);a.equal(orderedTasks(s)[0].id,'install5');s.tasks[5]=true;a.equal(orderedTasks(s)[0].id,'version');s.settings.done_version='yes';a.equal(orderedTasks(s)[0].id,'storage');const tasks=orderedTasks(s);let done=false;for(const t of tasks){if(t.done)done=true;else a.ok(!done);}}
console.log('PASS: 17 tareas, orden de pendientes, cambio de fase y completadas al final.');
