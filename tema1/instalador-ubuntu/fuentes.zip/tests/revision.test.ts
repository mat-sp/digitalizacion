import {strict as a} from 'node:assert';
import {writeFileSync} from 'node:fs';
import {initial,install,finishJob} from '../lib/sim/machine';
import {ubuntuNext,authenticateUbuntu} from '../lib/sim/flows';
import {audit} from '../lib/sim/audit';
import {makeReport,reportLines} from '../lib/sim/report';
import {translate} from '../lib/sim/i18n';
const s=initial('ubuntu');s.usb.location='pc';s.usb.bootable=true;a.throws(()=>install(s),/cuenta/);s.step=5;s.settings.method='automated';a.throws(()=>ubuntuNext(s),/desactivada/);s.settings.method='interactive';s.step=10;a.throws(()=>ubuntuNext(s));s.user.name='María Pérez';s.user.login='maria';s.user.password='MiClavePropia!';s.user.confirm='MiClavePropia!';ubuntuNext(s);install(s);finishJob(s);s.screen='login';a.throws(()=>authenticateUbuntu(s,'Practica123!'));authenticateUbuntu(s,'MiClavePropia!');a.equal(s.screen,'welcome');
const before=structuredClone(s);s.settings.theme='dark';s.settings.accent='green';s.user.password='NuevaClave';audit(before,s);a.ok(s.history.some(x=>x.includes('theme')));a.ok(!s.history.join(' ').includes('NuevaClave'));s.settings.student='María Pérez';s.settings.answer0='Copiar la ISO no crea por sí solo el cargador de arranque del USB.';for(let i=0;i<90;i++)s.history.push('12:30:00 · Comprobación del equipo simulado y configuración del dispositivo '+i);const bytes=makeReport(s);writeFileSync('/workspace/scratch/2415b668f3aa/informe_prueba.pdf',bytes);a.ok(!reportLines(s).join(' ').includes('NuevaClave'));a.equal(translate('Configuración'),'Settings');a.equal(translate('Rufus · Preparación del USB'),'Rufus · USB preparation');console.log('PASS: cuenta obligatoria, autoinstall bloqueado, contraseña propia, auditoría sin secretos, PDF y traducción.');
